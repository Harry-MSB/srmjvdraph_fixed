# DRAPH — AI Expo 2026–27 · Sri R.M. Jain Vidhyashram Sr. Sec. School

DRAPH is the holographic AI guide for SRMJV's first-ever AI Expo — a
free-floating hologram robot (equal parts Eilik's cuteness and EVE's
floating grace) that greets visitors, answers questions about the expo
by voice or text, and speaks back with a genuinely natural voice.

It ships with **two brains you can switch between live**, from a toggle
right above the message box:

- **Script Bot** — instant, offline, zero-cost keyword matching against
  the facts in `js/data.js`. No internet, no API key needed. This is
  the reliable fallback — it always works, wifi or no wifi.
- **Chat Bot** — open-ended conversation via the real Gemini API
  (Google's Interactions API), for visitors who want to ask DRAPH
  *anything*. **Works out of the box** — a Gemini key is already built
  in (see "About the built-in API key" below for what that means and
  how to change it).

Both go through the exact same robot performance — rush to center,
enlarge, explain with animated eyes/mouth/hands, speak, dissolve away
— and both speak with the same natural voice.

---

## Quick start

```bash
cd DRAPH
python3 install.py          # one-time — installs the one Python dependency
python3 server/server.py
```

Then open **http://localhost:8080**. Script Bot, Chat Bot, and natural
voice all work immediately — nothing else to configure.

`install.py` just runs `pip install -r requirements.txt` using whatever
Python you launched it with (so there's no ambiguity if your machine has
more than one), and automatically retries with `--break-system-packages`
if your system protects its global Python environment (common on modern
Debian/Ubuntu and Homebrew Python) — this is safe for a one-machine demo
setup where a virtual environment would just be one more step to
remember at the actual expo.

The old "just open index.html directly" approach still *mostly* works
for Script Bot, but the microphone, Chat Bot, and natural voice all need
an actual server behind them — so running `server.py` is the way to run
DRAPH, including at the expo itself.

---

## Natural voice

DRAPH speaks with Gemini's own text-to-speech (`gemini-3.1-flash-tts-preview`,
voice "Sulafat") instead of your OS's built-in robotic-sounding voice —
this is what makes it sound like a person talking, not a screen reader.
Every response gets a quick "say this warmly and naturally" instruction
before being spoken, and a couple of specific pronunciation fixes are
applied first (the previous behaviour of reading "2026–27" as individual
digits "two... zero... two... six..." instead of "twenty twenty-six to
twenty-seven" is fixed — the abbreviated year range is spelled out in
full before it ever reaches the speech engine, on both the natural-voice
path and the fallback path below).

If the server can't reach Gemini for any reason (offline, key removed,
quota hit), DRAPH automatically falls back to the browser's own voice
instead of staying silent — visitors always get *a* voice, just possibly
a less natural-sounding one until the connection is back.

To use a different one of Gemini's 30 built-in voices, set
`DRAPH_TTS_VOICE` (see "Configuration" below) — browse the voice list at
**https://ai.google.dev/gemini-api/docs/speech-generation**.

---

## About the built-in API key

A working Gemini API key ships inside `server/server.py` by request, so
Chat Bot and natural voice work with zero setup. A few things worth
knowing about that:

- **It's server-side only.** This file runs on your machine/laptop and
  is never sent to a visitor's browser — nobody interacting with DRAPH
  at the expo can see it just by using the kiosk or opening dev tools
  on their own device.
- **It IS visible to anyone who reads this project's source code.** If
  you put this project on GitHub (even "just to share with a teacher"),
  upload it somewhere public, or hand the folder to someone else, they
  can open `server.py` and read the key. Since it was also shared in
  plaintext to generate this build, treat it as already exposed —
  **rotating it is a good idea regardless**, whenever convenient:
  1. Go to **https://aistudio.google.com/apikey**, delete the old key,
     create a new one.
  2. Either paste the new one into `server.py` directly (search for
     `_BUILT_IN_DEFAULT_KEY`), or — better — leave `server.py` alone
     and instead put the new key in a local `.env` file:
     ```bash
     cp .env.example .env
     # edit .env, paste the new key in
     ```
     An environment variable or `.env` file always overrides the
     built-in default, so this needs no code changes and `.env` is
     already in `.gitignore` — it's never committed if you do put this
     in git.
- **Before publishing this project anywhere public**, remove the key
  from `server.py` (replace it with an empty string) and use the `.env`
  method above instead. Script Bot doesn't need any of this and keeps
  working regardless.

**Cost/quota note:** both Chat Bot and natural voice call real, metered
APIs. The server applies small built-in delays between requests
(`DRAPH_MIN_REQUEST_GAP` / `DRAPH_TTS_MIN_REQUEST_GAP`) as a basic guard
against accidental rapid-fire use on a public kiosk, and caps chat
response length (`DRAPH_MAX_TOKENS`, 420 by default) since expo visitors
want a quick spoken answer, not an essay. Consider setting a budget
alert on the Google account this key belongs to before a live event.

### How Chat Bot stays consistent with Script Bot

The server reads the same `label`/`content` facts out of `js/data.js`
that Script Bot uses and feeds them to Gemini as context, so if a
visitor asks either bot "when's the fest," they get the same answer.
Edit `js/data.js` once — both bots pick it up (Chat Bot on next server
restart, Script Bot on next page load).

---

## Editing the real event details

Everything Script Bot says — and the facts Chat Bot is grounded in —
lives in **`js/data.js`**, at the top, clearly commented. Look for
`eventData` and fill in the real Fest Date, Timings, Participants,
Theme, and Smart Classroom details. Nothing else needs to change; the
placeholder "details coming soon" copy already renders correctly, so
there's no rush.

`commandData` and `smallTalkData` in the same file control voice
commands ("mute", "repeat that", "clear chat"...) and small talk
(greetings, thanks...) — add synonyms freely, longer phrases score
higher than short ones so it's safe to add both.

---

## Configuration

All optional, all set the same way — environment variables, or lines in
a local `.env` file (see `.env.example`):

| Variable | Default | What it does |
|---|---|---|
| `GEMINI_API_KEY` | *(built in)* | Overrides the built-in key |
| `PORT` | `8080` | Server port |
| `DRAPH_MODEL` | `gemini-3-flash-preview` | Chat Bot's text model |
| `DRAPH_MAX_TOKENS` | `420` | Max length of a Chat Bot reply |
| `DRAPH_MIN_REQUEST_GAP` | `1.5` | Seconds between Chat Bot requests |
| `DRAPH_TTS_MODEL` | `gemini-3.1-flash-tts-preview` | Natural voice model |
| `DRAPH_TTS_VOICE` | `Sulafat` | Which of Gemini's 30 voices to use |
| `DRAPH_TTS_MIN_REQUEST_GAP` | `0.6` | Seconds between voice requests |

---

## What's inside

```
DRAPH/
├── index.html                 the whole app shell
├── install.py                  one-time dependency installer
├── requirements.txt             Python dependencies (just google-genai)
├── css/
│   ├── base.css                tokens, 3 hologram color themes, backdrop, hero
│   ├── robot.css                the robot: SVG parts, spring-driven motion states
│   └── chat.css                 chat log, explain panel, mode toggle, input bar
├── js/
│   ├── motion-pref.js           live "Calm Mode" flag, loaded first
│   ├── data.js                  ← edit this for real event facts
│   ├── background.js            circuit traces, neural net canvas, code drift
│   ├── robot.js                 spring-physics position system + all animation
│   ├── audio.js                 boot sound, typing tick, natural voice + fallback, STT
│   ├── cursor.js                 custom cursor + click ripple
│   ├── chatbot-api.js            talks to OUR server only, never to Gemini directly
│   ├── chat.js                   matching engine, mode switch, delivery choreography
│   └── main.js                   boot sequence, wiring, hero → chat transition
├── assets/
│   ├── intro.wav, intro_end.wav  your provided boot sequence audio
│   ├── typing-tick.wav           a short, pitched-up, filtered clip derived from
│   │                             your conversation.wav (see design notes below)
│   └── source/conversation.wav   your original file, kept for reference — not
│                                 loaded by the app itself
├── server/
│   └── server.py                serves the frontend AND proxies Chat Bot / voice
├── .env.example                  copy to .env to override the built-in key
└── .gitignore
```

No build step, no bundler, no npm install for the frontend — open the
files and edit directly.

---

## Customizing

Tap the gear icon (top-right) for:
- **Hologram color** — three built-in themes (cyan/magenta, amber/violet,
  emerald/rose), instant swap, no reload.
- **Voice speed** — slow / normal / fast (applies to both the natural
  voice and the browser-voice fallback).
- **Full motion / Calm Mode** — turns down decorative animation, useful
  on older hardware or for accessibility.

The mute button (top-right, always red when muted / green when
unmuted) and the Script Bot / Chat Bot toggle (above the message box)
are the two other always-visible controls.

---

## Notes on a few design decisions

- **Why a Python server instead of just static files?** The API key has
  to live somewhere the browser can't read it, and natural voice audio
  has to be generated somewhere too. A tiny local server handles both
  without needing external hosting — it runs entirely on the laptop at
  the expo. Script Bot has zero dependency on any of it.
- **Why does Script Bot never touch the server's /api routes?** So a
  wifi hiccup or a missing/removed API key never breaks the core FAQ
  experience — Script Bot is pure client-side keyword matching.
- **About the robot's SVG** — one continuously floating figure (no
  hologram pad), built from a single spring-physics position system so
  idle drifting, the rush-to-center on a new question, and the
  explain-mode enlarge all move through the same code path instead of
  three separate animations fighting each other.
- **About the audio** — `typing-tick.wav` is not a raw clip of your
  conversation recording played back; a short, percussive moment was
  selected, pitch-shifted up, and filtered so it reads as an abstract
  "digital tick" rather than recognizable speech, then used (with small
  per-play pitch/volume variation) as the typing sound. The original
  file is kept untouched in `assets/source/` in case you want to derive
  a different clip later.

Enjoy the expo!
