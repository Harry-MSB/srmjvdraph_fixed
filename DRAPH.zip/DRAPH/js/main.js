/* ============================================================
   DRAPH — main.js
   Boot sequence + module wiring. Loaded last, after every other
   module, so everything it references already exists.
   ============================================================ */

(() => {
  const BOOT_LINES = [
    "booting DRAPH core...",
    "loading AI EXPO 2026\u201327 knowledge base...",
    "calibrating hologram projector...",
    "ready. tap below to begin."
  ];
  const LOG_LINES = [
    "sensor.array ... <span class=\"ok\">OK</span>",
    "voice.module ... <span class=\"ok\">OK</span>",
    "vision.core ... <span class=\"ok\">OK</span>",
    "hologram.emitter ... <span class=\"ok\">OK</span>",
    "knowledge.base ... <span class=\"ok\">SYNCED</span>",
    "visitor detected \u2014 welcome!",
    "first AI Expo @ SRMJV",
    "status: <span class=\"ok\">ONLINE</span>"
  ];

  function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }

  async function runBootSequence(consoleEl, enterBtn) {
    Robot.playPowerOn();
    Audio_.playIntroLoop();
    for (let li = 0; li < BOOT_LINES.length; li++) {
      const lineEl = document.createElement("p");
      lineEl.className = "console-line";
      const textSpan = document.createElement("span");
      if (li === BOOT_LINES.length - 1) textSpan.className = "ok";
      const cursorSpan = document.createElement("span");
      cursorSpan.className = "cursor";
      lineEl.appendChild(textSpan);
      lineEl.appendChild(cursorSpan);
      consoleEl.appendChild(lineEl);

      const text = "> " + BOOT_LINES[li];
      if (window.DRAPH_MOTION.reduced()) {
        textSpan.textContent = text;
      } else {
        for (const ch of text) {
          textSpan.textContent += ch;
          await wait(13 + Math.random() * 15);
        }
      }
      cursorSpan.remove();
      await wait(180);
    }
    Audio_.stopIntroLoop();
    Audio_.playIntroEnd();
    enterBtn.disabled = false;
    enterBtn.classList.add("ready");
  }

  function startLogTicker(rootEl) {
    if (!rootEl) return;
    const linesEl = rootEl.querySelector(".log-ticker-lines");
    if (!linesEl) return;
    const shown = [];
    function addLine() {
      const text = LOG_LINES[(Math.random() * LOG_LINES.length) | 0];
      const p = document.createElement("div");
      p.className = "log-line";
      p.innerHTML = text;
      linesEl.appendChild(p);
      shown.push(p);
      if (shown.length > 3) shown.shift().remove();
    }
    addLine(); addLine(); addLine();
    setInterval(() => { if (!document.hidden) addLine(); }, 3400);
  }

  async function goToChatApp(heroEl, chatAppEl) {
    Audio_.unlock();
    heroEl.classList.add("exiting");
    chatAppEl.hidden = false;
    void chatAppEl.offsetWidth;
    await Robot.enterChatIdle();
    requestAnimationFrame(() => heroEl.classList.add("faded"));
    await wait(650);
    heroEl.hidden = true;
    heroEl.classList.remove("exiting", "faded");
    Chat.showWelcome();
  }

  function init() {
    const heroEl = document.getElementById("hero");
    const chatAppEl = document.getElementById("chatApp");
    const heroSpacer = document.querySelector(".hero-robot-spacer");
    const robotStage = document.getElementById("robotStage");
    const enterBtn = document.getElementById("enterBtn");
    const bootConsole = document.getElementById("bootConsole");

    Background.init();
    Cursor.init();
    Audio_.init();
    Robot.init({ heroSpacer, stage: robotStage });

    Chat.init({
      chatLog: document.getElementById("chatLog"),
      explainPanel: document.getElementById("explainPanel"),
      explainTextInner: document.getElementById("explainText"),
      nodeGrid: document.getElementById("nodeGrid"),
      inputForm: document.getElementById("inputForm"),
      userInput: document.getElementById("userInput"),
      micBtn: document.getElementById("micBtn"),
      micStatus: document.getElementById("micStatus"),
      muteToggle: document.getElementById("muteToggle"),
      settingsToggle: document.getElementById("settingsToggle"),
      settingsPanel: document.getElementById("settingsPanel"),
      motionToggle: document.getElementById("motionToggle"),
      modeButtons: document.querySelectorAll(".mode-btn")
    });

    startLogTicker(document.querySelector(".log-ticker-hero"));
    runBootSequence(bootConsole, enterBtn);

    enterBtn.addEventListener("click", () => {
      if (enterBtn.disabled) return;
      enterBtn.disabled = true;
      goToChatApp(heroEl, chatAppEl);
    });
  }

  init();
})();
