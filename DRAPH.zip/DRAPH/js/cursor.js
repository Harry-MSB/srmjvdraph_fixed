/* ============================================================
   DRAPH — cursor.js
   Smooth cursor follow using frame-rate-independent exponential
   smoothing (no fixed-step pulse/ping — that was the old jitter
   source). Ripple feedback is a one-shot animation fired only on
   real clicks/taps, never as an idle loop.
   ============================================================ */

const Cursor = (() => {
  const isFinePointer = window.matchMedia && window.matchMedia("(pointer: fine)").matches;

  let dot, ring, rippleLayer;
  let tx = 0, ty = 0, rx = 0, ry = 0, dx = 0, dy = 0;
  let lastT = 0, started = false;

  function loop(t) {
    requestAnimationFrame(loop);
    const dt = lastT ? Math.min(48, t - lastT) : 16;
    lastT = t;
    const smooth = 1 - Math.pow(0.0007, dt); // frame-rate independent ease factor
    dx += (tx - dx) * smooth;
    dy += (ty - dy) * smooth;
    rx += (tx - rx) * (smooth * 0.62);
    ry += (ty - ry) * (smooth * 0.62);
    if (dot) dot.style.transform = `translate3d(${dx.toFixed(1)}px, ${dy.toFixed(1)}px, 0)`;
    if (ring) ring.style.transform = `translate3d(${rx.toFixed(1)}px, ${ry.toFixed(1)}px, 0)`;
  }

  function spawnRipple(x, y) {
    if (!rippleLayer) return;
    const el = document.createElement("div");
    el.className = "click-ripple";
    el.style.left = x + "px"; el.style.top = y + "px";
    rippleLayer.appendChild(el);
    el.addEventListener("animationend", () => el.remove(), { once: true });
  }

  function isInteractive(el) {
    return !!(el && el.closest && el.closest("a, button, input, textarea, .node-btn, .icon-btn, .swatch-btn, .seg-btn, [role='button']"));
  }

  function init() {
    dot = document.querySelector(".cursor-dot");
    ring = document.querySelector(".cursor-ring");
    rippleLayer = document.querySelector(".click-ripple-layer");

    if (isFinePointer) {
      window.addEventListener("pointermove", (e) => {
        tx = e.clientX; ty = e.clientY;
        if (!started) { started = true; dx = rx = tx; dy = ry = ty; }
        const hovering = isInteractive(e.target);
        if (dot) dot.classList.toggle("hover", hovering);
        if (ring) ring.classList.toggle("hover", hovering);
      }, { passive: true });
      requestAnimationFrame(loop);
    }

    window.addEventListener("pointerdown", (e) => {
      if (!window.DRAPH_MOTION.reduced()) spawnRipple(e.clientX, e.clientY);
    }, { passive: true });
  }

  return { init };
})();
