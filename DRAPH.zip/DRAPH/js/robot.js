/* ============================================================
   DRAPH — robot.js
   ------------------------------------------------------------
   Everything about how the robot MOVES lives here. Geometry was
   hand-tuned and visually verified before integration (see the
   dev notes in README.md if you want to tweak the SVG further).

   ARCHITECTURE
   One spring-physics system drives every position/size change —
   idle drifting AND the "rush to center" AND the explain-mode
   enlarge/shift all go through the same `pos`/`scale` springs.
   The only thing that differs between them is which *target*
   they're chasing (`base.x/y` + `scale.target`), which is set
   discretely by setMode(). This is why the robot can glide
   continuously from the hero screen into the chat app with no
   special-cased "flight" animation — it's just one target change.

   A spring toward a moving "wander" sub-target gives the organic
   idle float; re-randomizing that sub-target on an irregular timer
   (instead of a fixed loop) is what keeps it from reading as an
   obviously-looping CSS animation.
   ============================================================ */

const Robot = (() => {

  const NARROW_BREAKPOINT = 760;
  let tabVisible = true;
  document.addEventListener("visibilitychange", () => { tabVisible = !document.hidden; });

  /* ---------------- validated SVG geometry ---------------- */
  const SILHOUETTE_D = `M80,18 C103,18 119,34 119,58 C119,76 110,86 104,96 C118,104 128,120 128,138 C128,158 120,176 106,190 C97,200 89,206 80,208 C71,206 63,200 54,190 C40,176 32,158 32,138 C32,120 42,104 56,96 C50,86 41,76 41,58 C41,34 57,18 80,18 Z`;
  const ARM_R_D = `M104,108 C114,106 122,110 127,120 C130,127 129,135 124,140 C118,138 111,130 106,120 C102,114 100,110 104,108 Z`;
  const ARM_L_D = `M56,108 C46,106 38,110 33,120 C30,127 31,135 36,140 C42,138 49,130 54,120 C58,114 60,110 56,108 Z`;
  const CORE_D = `M80,92 C74,98 73,106 80,113 C87,106 86,98 80,92 Z`;

  function buildRobotInnerSVG() {
    return `
      <defs>
        <filter id="chromaGlitch" x="-40%" y="-40%" width="180%" height="180%" color-interpolation-filters="sRGB">
          <feOffset in="SourceGraphic" dx="-2.4" dy="0" result="cyanShift"/>
          <feColorMatrix in="cyanShift" type="matrix" values="0 0 0 0 0  0 0 0 0 1  0 0 0 0 1  0 0 0 0.85 0" result="cyanTint"/>
          <feOffset in="SourceGraphic" dx="2.4" dy="0" result="magShift"/>
          <feColorMatrix in="magShift" type="matrix" values="1 0 0 0 1  0 0 0 0 0  0 0 0 0 1  0 0 0 0.85 0" result="magTint"/>
          <feMerge>
            <feMergeNode in="cyanTint"/><feMergeNode in="magTint"/><feMergeNode in="SourceGraphic"/>
          </feMerge>
        </filter>
      </defs>
      <path class="holo-silhouette" d="${SILHOUETTE_D}"/>
      <ellipse class="holo-ear" cx="34" cy="57" rx="6.5" ry="8.5"/>
      <ellipse class="holo-ear" cx="126" cy="57" rx="6.5" ry="8.5"/>
      <ellipse class="holo-cap" cx="80" cy="25" rx="16" ry="7.5"/>
      <rect class="holo-visor" x="48" y="35" width="64" height="46" rx="23"/>
      <g class="eye-l">
        <rect class="holo-eye" x="56" y="44" width="15" height="22" rx="7.5"/>
        <ellipse class="holo-eye-glint" cx="64" cy="51.5" rx="2.8" ry="3.6"/>
      </g>
      <g class="eye-r">
        <rect class="holo-eye" x="89" y="44" width="15" height="22" rx="7.5"/>
        <ellipse class="holo-eye-glint" cx="97" cy="51.5" rx="2.8" ry="3.6"/>
      </g>
      <ellipse class="holo-mouth viseme-closed" cx="80" cy="71" rx="10" ry="5"/>
      <path class="holo-core" d="${CORE_D}"/>
      <g class="arm-r">
        <path class="holo-arm" d="${ARM_R_D}"/>
        <g class="hand-wrap">
          <ellipse class="holo-hand" cx="128" cy="144" rx="11" ry="15"/>
          <ellipse class="holo-hand-glint" cx="124.5" cy="139" rx="2.4" ry="3.2"/>
        </g>
      </g>
      <g class="arm-l">
        <path class="holo-arm" d="${ARM_L_D}"/>
        <g class="hand-wrap">
          <ellipse class="holo-hand" cx="32" cy="144" rx="11" ry="15"/>
          <ellipse class="holo-hand-glint" cx="28.5" cy="139" rx="2.4" ry="3.2"/>
        </g>
      </g>
    `;
  }

  /* ---------------- critically/under-damped spring ---------------- */
  class Spring {
    constructor(value, stiffness, damping) {
      this.value = value; this.target = value; this.vel = 0;
      this.k = stiffness; this.d = damping;
    }
    update(dt) {
      const accel = (this.target - this.value) * this.k - this.vel * this.d;
      this.vel += accel * dt;
      this.value += this.vel * dt;
    }
    snap(v) { this.value = v; this.target = v; this.vel = 0; }
  }

  const els = {};
  let pos, scale, wander;
  let mode = "hero";
  const base = { x: 0, y: 0 };
  let wanderRadius = { x: 40, y: 34 };
  let lastSafeBounds = null;
  let wanderRetimeMs = [2600, 4400];
  let nextWanderAt = 0;
  let lastT = 0;
  let speaking = false;
  let speakTimer = null, gestureTimer = null, blinkTimer = null, lookTimer = null;

  function isNarrow() { return window.innerWidth <= NARROW_BREAKPOINT; }
  function rand(a, b) { return a + Math.random() * (b - a); }

  function heroRect() { return els.heroSpacer.getBoundingClientRect(); }
  function stageRect() { return els.stage.getBoundingClientRect(); }

  function pickNewWanderTarget(immediate) {
    wander.x.target = rand(-wanderRadius.x, wanderRadius.x);
    wander.y.target = rand(-wanderRadius.y, wanderRadius.y);
    if (immediate) { wander.x.snap(wander.x.target); wander.y.snap(wander.y.target); }
    const [lo, hi] = wanderRetimeMs;
    nextWanderAt = performance.now() + rand(lo, hi);
  }

  function setMode(newMode) {
    mode = newMode;
    if (mode === "hero") {
      const r = heroRect();
      if (r.width < 2) return; // not laid out yet — bail, caller can retry
      applySafeBounds(r, 0.5, 0.5, 1, 0.22, 0.2);
      wanderRetimeMs = [2400, 4000];
    } else if (mode === "idle") {
      const r = stageRect();
      applySafeBounds(r, 0.5, 0.48, 1, 0.30, 0.24);
      wanderRetimeMs = [2600, 4600];
    } else if (mode === "centering") {
      const r = stageRect();
      applySafeBounds(r, 0.5, 0.48, 1, 0.05, 0.04);
      wanderRetimeMs = [1400, 1900];
    } else if (mode === "explain") {
      const r = stageRect();
      const anchor = isNarrow() ? { x: 0.5, y: 0.21 } : { x: 0.28, y: 0.5 };
      const explainScale = isNarrow() ? 1.32 : 1.55;
      applySafeBounds(r, anchor.x, anchor.y, explainScale, 0.02, 0.018);
      wanderRetimeMs = [1100, 1700];
    }
    pickNewWanderTarget(false);
  }

  /* Figures out where the robot's CENTER is allowed to go so that its
     rendered edges — at whatever scale this mode uses — never leave the
     given rect. offsetWidth/offsetHeight are used (not getBoundingClientRect)
     because they reflect the figure's un-transformed CSS size regardless of
     the scale currently mid-transition on its ancestor, so this stays
     correct even while the previous mode's scale animation is still
     settling. This is what keeps the robot strictly inside the page and
     out of the topbar, however far it wanders or however large it grows. */
  function applySafeBounds(r, anchorXPct, anchorYPct, targetScale, radiusXPct, radiusYPct) {
    scale.target = targetScale;
    const figW = (els.figure.offsetWidth || 160) * targetScale;
    const figH = (els.figure.offsetHeight || 232) * targetScale;
    const halfW = figW / 2, halfH = figH / 2;
    const margin = 6;

    let minCx = r.left + halfW + margin, maxCx = r.left + r.width - halfW - margin;
    let minCy = r.top + halfH + margin, maxCy = r.top + r.height - halfH - margin;
    if (minCx > maxCx) { const mid = r.left + r.width / 2; minCx = maxCx = mid; }
    if (minCy > maxCy) { const mid = r.top + r.height / 2; minCy = maxCy = mid; }

    const wantX = r.left + r.width * anchorXPct;
    const wantY = r.top + r.height * anchorYPct;
    base.x = Math.min(Math.max(wantX, minCx), maxCx);
    base.y = Math.min(Math.max(wantY, minCy), maxCy);

    const safeRx = Math.max(0, Math.min(base.x - minCx, maxCx - base.x));
    const safeRy = Math.max(0, Math.min(base.y - minCy, maxCy - base.y));
    wanderRadius = { x: Math.min(r.width * radiusXPct, safeRx), y: Math.min(r.height * radiusYPct, safeRy) };

    // Hard-clamp any in-flight wander offset to the new radius immediately.
    // Without this, a wander value built up under a WIDE radius (idle) can
    // briefly exceed a much TIGHTER new radius (explain) while its spring
    // is still easing down — which is exactly what let the robot poke
    // above the stage into the topbar during the rush-to-explain move.
    // Safety bounds must hold even transiently, so this snaps, it doesn't ease.
    wander.x.value = Math.max(-wanderRadius.x, Math.min(wanderRadius.x, wander.x.value));
    wander.y.value = Math.max(-wanderRadius.y, Math.min(wanderRadius.y, wander.y.value));

    lastSafeBounds = { minCx, maxCx, minCy, maxCy };
  }

  function frame(t) {
    requestAnimationFrame(frame);
    if (!tabVisible || !els.anchor) { lastT = 0; return; }
    const dt = lastT ? Math.min(0.05, (t - lastT) / 1000) : 0.016;
    lastT = t;

    if (window.DRAPH_MOTION.reduced()) {
      pos.x.snap(base.x); pos.y.snap(base.y); scale.snap(scale.target);
    } else {
      if (t >= nextWanderAt) pickNewWanderTarget(false);
      wander.x.update(dt); wander.y.update(dt);
      pos.x.target = base.x + wander.x.value;
      pos.y.target = base.y + wander.y.value;
      pos.x.update(dt); pos.y.update(dt);
      scale.update(dt);
    }

    // Final defensive clamp: whatever the springs computed, never render
    // outside the last-known-safe rect. This is a plain clamp on the
    // OUTPUT only (springs keep their own state untouched, so easing
    // keeps working normally) — a last-resort net in case a fast target
    // change ever lets a frame slip past bounds before it settles.
    if (lastSafeBounds) {
      const b = lastSafeBounds;
      if (b.minCx <= b.maxCx) pos.x.value = Math.min(Math.max(pos.x.value, b.minCx), b.maxCx);
      if (b.minCy <= b.maxCy) pos.y.value = Math.min(Math.max(pos.y.value, b.minCy), b.maxCy);
    }

    els.anchor.style.transform = `translate3d(${pos.x.value.toFixed(2)}px, ${pos.y.value.toFixed(2)}px, 0) scale(${scale.value.toFixed(4)})`;
  }

  /* ---------------- power-on / glitch flourish ---------------- */
  function playPowerOn() {
    els.figure.classList.remove("power-on"); void els.figure.offsetWidth;
    els.figure.classList.add("power-on", "glitching");
    setTimeout(() => els.figure.classList.remove("glitching"), 420);
    setTimeout(() => els.figure.classList.remove("power-on"), 950);
  }

  function reactAlert() {
    els.figure.classList.add("alert");
    setTimeout(() => els.figure.classList.remove("alert"), 380);
  }

  function setThinking(on) {
    els.eyeRectL.classList.toggle("squint", on);
    els.eyeRectR.classList.toggle("squint", on);
  }

  function wait(ms) { return new Promise((res) => setTimeout(res, ms)); }

  async function enterChatIdle() { setMode("idle"); }

  async function rushToExplain() {
    setMode("centering");
    await wait(560);
    setMode("explain");
    els.figure.classList.add("glitching");
    setTimeout(() => els.figure.classList.remove("glitching"), 360);
    await wait(460);
  }

  async function returnToIdle() {
    setMode("idle");
    await wait(480);
  }

  /* ---------------- blink + look-around (always running) ---------------- */
  function doBlink() {
    els.eyeL.classList.add("blink-now"); els.eyeR.classList.add("blink-now");
    setTimeout(() => { els.eyeL.classList.remove("blink-now"); els.eyeR.classList.remove("blink-now"); }, 120);
  }
  function scheduleBlink() {
    if (window.DRAPH_MOTION.reduced()) { setTimeout(scheduleBlink, 4000); return; }
    const delay = rand(2600, 5600);
    blinkTimer = setTimeout(() => {
      doBlink();
      if (Math.random() < 0.18) setTimeout(doBlink, 170);
      scheduleBlink();
    }, delay);
  }
  function scheduleLook() {
    if (window.DRAPH_MOTION.reduced()) { setTimeout(scheduleLook, 4000); return; }
    const delay = rand(1800, 4400);
    lookTimer = setTimeout(() => {
      const dx = rand(-2.4, 2.4), dy = rand(-1.6, 1.6);
      els.glintL.style.transform = `translate(${dx.toFixed(1)}px, ${dy.toFixed(1)}px)`;
      els.glintR.style.transform = `translate(${dx.toFixed(1)}px, ${dy.toFixed(1)}px)`;
      setTimeout(() => { els.glintL.style.transform = ""; els.glintR.style.transform = ""; }, rand(900, 1400));
      scheduleLook();
    }, delay);
  }

  /* ---------------- speaking director: mouth + gestures ---------------- */
  const VISEME_CLASSES = ["viseme-closed", "viseme-small", "viseme-open", "viseme-wide", "viseme-flat", "viseme-smirk"];
  const VISEME_CYCLE = ["viseme-small", "viseme-open", "viseme-small", "viseme-wide", "viseme-flat", "viseme-open", "viseme-small", "viseme-closed", "viseme-open"];
  let lastViseme = "";
  function pickViseme() {
    let v;
    do { v = VISEME_CYCLE[(Math.random() * VISEME_CYCLE.length) | 0]; } while (v === lastViseme && Math.random() < 0.85);
    lastViseme = v;
    return v;
  }
  function setViseme(cls) {
    els.mouth.classList.remove(...VISEME_CLASSES);
    els.mouth.classList.add(cls);
  }
  function scheduleViseme() {
    if (!speaking) return;
    setViseme(pickViseme());
    speakTimer = setTimeout(scheduleViseme, rand(95, 190));
  }
  function clearGestures() {
    els.armR.classList.remove("gesture-r", "gesture-r-small");
    els.armL.classList.remove("gesture-l", "gesture-l-small");
    els.handWrapR.classList.remove("hand-flourish");
    els.handWrapL.classList.remove("hand-flourish");
  }
  function pulseGesture(which) {
    if (which === "r" || which === "both") {
      els.armR.classList.add(Math.random() < 0.5 ? "gesture-r" : "gesture-r-small");
      els.handWrapR.classList.add("hand-flourish");
    }
    if (which === "l" || which === "both") {
      els.armL.classList.add(Math.random() < 0.5 ? "gesture-l" : "gesture-l-small");
      els.handWrapL.classList.add("hand-flourish");
    }
    setTimeout(clearGestures, rand(300, 420));
  }
  function scheduleGesture() {
    if (!speaking) return;
    const roll = Math.random();
    pulseGesture(roll < 0.4 ? "r" : roll < 0.8 ? "l" : "both");
    gestureTimer = setTimeout(scheduleGesture, rand(550, 970));
  }

  function setSpeaking(on) {
    speaking = on;
    els.figure.classList.toggle("is-speaking", on);
    clearTimeout(speakTimer); clearTimeout(gestureTimer);
    if (on) {
      scheduleViseme();
      scheduleGesture();
    } else {
      setViseme("viseme-closed");
      clearGestures();
    }
  }
  /* Called externally by audio.js on a TTS word-boundary event, when the
     browser supports it, for a touch tighter lip sync than the timer alone. */
  function onSpeechBoundary() {
    if (!speaking) return;
    setViseme(pickViseme());
  }

  /* ---------------- resize / orientation ---------------- */
  function handleResize() {
    if (!els.anchor) return;
    setMode(mode === "centering" ? "idle" : mode);
  }

  function init(opts) {
    els.anchor = document.getElementById("robotAnchor");
    els.figure = document.getElementById("robotFigure");
    els.svg = document.getElementById("robotSvg");
    els.heroSpacer = opts.heroSpacer;
    els.stage = opts.stage;

    els.svg.innerHTML = buildRobotInnerSVG();
    els.mouth = els.svg.querySelector(".holo-mouth");
    els.eyeL = els.svg.querySelector(".eye-l");
    els.eyeR = els.svg.querySelector(".eye-r");
    els.eyeRectL = els.eyeL.querySelector(".holo-eye");
    els.eyeRectR = els.eyeR.querySelector(".holo-eye");
    els.glintL = els.eyeL.querySelector(".holo-eye-glint");
    els.glintR = els.eyeR.querySelector(".holo-eye-glint");
    els.armR = els.svg.querySelector(".arm-r");
    els.armL = els.svg.querySelector(".arm-l");
    els.handWrapR = els.armR.querySelector(".hand-wrap");
    els.handWrapL = els.armL.querySelector(".hand-wrap");

    pos = { x: new Spring(0, 42, 8.2), y: new Spring(0, 42, 8.2) };
    scale = new Spring(1, 95, 19.5);
    wander = { x: new Spring(0, 9, 6.5), y: new Spring(0, 9, 6.5) };

    applySafeBounds(heroRect(), 0.5, 0.5, 1, 0.22, 0.2);
    pos.x.snap(base.x); pos.y.snap(base.y); scale.snap(1);
    pickNewWanderTarget(true);

    requestAnimationFrame(frame);
    scheduleBlink();
    scheduleLook();

    let resizeT = null, orientT = null;
    window.addEventListener("resize", () => { clearTimeout(resizeT); resizeT = setTimeout(handleResize, 150); });
    window.addEventListener("orientationchange", () => { clearTimeout(orientT); orientT = setTimeout(handleResize, 350); });
  }

  return {
    init, playPowerOn, enterChatIdle, rushToExplain, returnToIdle,
    reactAlert, setThinking, setSpeaking, onSpeechBoundary,
    _debug: () => ({ mode, base: { ...base }, lastSafeBounds, wanderRadius,
      pos: { x: pos.x.value, y: pos.y.value }, wander: { x: wander.x.value, y: wander.y.value },
      scale: scale.value, scaleTarget: scale.target,
      figSize: { w: els.figure.offsetWidth, h: els.figure.offsetHeight } })
  };
})();
