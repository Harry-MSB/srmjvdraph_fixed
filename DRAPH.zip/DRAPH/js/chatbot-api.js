/* ============================================================
   DRAPH — chatbot-api.js
   ------------------------------------------------------------
   Talks ONLY to our own local server's /api/chat and /api/health
   routes — never to Gemini directly. The API key never reaches
   this file, the browser, or anyone inspecting network traffic
   on the kiosk; see server/server.py for why that matters.

   If this page was opened directly as a file:// (no server.py
   running), these calls simply fail and Chat Bot reports itself
   unavailable — Script Bot is completely unaffected either way.
   ============================================================ */

const ChatBotAPI = (() => {
  let available = false;
  let configured = false;
  let previousInteractionId = null;

  async function checkHealth() {
    try {
      const res = await fetch("/api/health", { cache: "no-store" });
      if (!res.ok) { available = false; configured = false; return { available, configured }; }
      const data = await res.json();
      available = true;
      configured = !!data.chatBotConfigured;
    } catch (e) {
      available = false; configured = false;
    }
    return { available, configured };
  }

  async function ask(message) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);
    let res;
    try {
      res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, previous_interaction_id: previousInteractionId }),
        signal: controller.signal
      });
    } catch (e) {
      if (e && e.name === "AbortError") throw new Error("That took too long to answer — please try again.");
      throw new Error("Can't reach the DRAPH server. Is it still running?");
    } finally {
      clearTimeout(timeoutId);
    }
    let data = {};
    try { data = await res.json(); } catch (e) { /* fall through to generic error below */ }
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status}).`);
    previousInteractionId = data.interaction_id || previousInteractionId;
    return data.text || "";
  }

  function resetConversation() { previousInteractionId = null; }
  function isAvailable() { return available; }
  function isConfigured() { return configured; }

  return { checkHealth, ask, resetConversation, isAvailable, isConfigured };
})();