/* ============================================================
   DRAPH — chat.js
   Matching engine (commands → small talk → event topics →
   fallback) + all message rendering + the explain-stage
   choreography that ties Robot + Audio_ + data.js together.
   ============================================================ */

const ICONS = {
  calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></svg>`,
  clock: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/></svg>`,
  users: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M2.8 20c.7-3.4 3.2-5.4 6.2-5.4s5.5 2 6.2 5.4"/><circle cx="17.3" cy="8.6" r="2.4"/><path d="M16.2 14.8c2.4.4 4.2 2.1 4.8 4.8"/></svg>`,
  spark: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.8 5.6L19 10l-5.2 1.6L12 17l-1.8-5.4L5 10l5.2-1.4z"/></svg>`,
  monitor: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg>`,
  mic: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>`,
  send: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4Z"/></svg>`,
  unmuted: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M17 9a4 4 0 0 1 0 6M19.5 6.5a8 8 0 0 1 0 11"/></svg>`,
  muted: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M16 9l5 6M21 9l-5 6"/></svg>`,
  gear: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 13a7.9 7.9 0 0 0 0-2l2-1.5-2-3.4-2.4 1a8 8 0 0 0-1.7-1L15 3h-6l-.3 2.6a8 8 0 0 0-1.7 1l-2.4-1-2 3.4L4.6 11a7.9 7.9 0 0 0 0 2l-2 1.5 2 3.4 2.4-1c.5.4 1.1.8 1.7 1L9 21h6l.3-2.6c.6-.2 1.2-.6 1.7-1l2.4 1 2-3.4Z"/></svg>`,
  botAvatar: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="6"/></svg>`,
  userAvatar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="3.4"/><path d="M4.5 20c1-4 3.8-6 7.5-6s6.5 2 7.5 6"/></svg>`,
  scriptIcon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6h11M9 12h11M9 18h11"/><path d="M4.5 6h.01M4.5 12h.01M4.5 18h.01"/></svg>`,
  chatIcon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h9A2.5 2.5 0 0 1 18 6.5v6a2.5 2.5 0 0 1-2.5 2.5H9l-4 3.5v-3.5H6.5A2.5 2.5 0 0 1 4 12.5Z"/><path d="M18.2 3.6l.5 1.4 1.4.5-1.4.5-.5 1.4-.5-1.4-1.4-.5 1.4-.5z"/></svg>`
};

const Chat = (() => {

  let dom = {};
  let lastAnswer = null;
  let botMode = "script"; // "script" | "chat"

  function wait(ms) { return new Promise((r) => setTimeout(r, ms)); }
  function pickRandom(arr) { return arr[(Math.random() * arr.length) | 0]; }
  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }

  /* ---------------- matching engine ---------------- */
  function normalize(s) {
    return s.toLowerCase().replace(/[^\w\s]/g, " ").replace(/\s+/g, " ").trim();
  }
  function scoreAgainst(normInput, keywords) {
    let best = 0;
    for (const kw of keywords) {
      const nkw = normalize(kw);
      if (!nkw) continue;
      if (normInput === nkw) { best = Math.max(best, 100 + nkw.length); continue; }
      if (normInput.includes(nkw)) { best = Math.max(best, 10 + nkw.length * 2); continue; }
      const words = nkw.split(" ");
      if (words.length === 1 && normInput.split(" ").includes(words[0])) {
        best = Math.max(best, 6 + words[0].length);
      }
    }
    return best;
  }
  function matchCommand(n) {
    let best = null, bestScore = 0;
    for (const c of commandData) {
      const s = scoreAgainst(n, c.keywords);
      if (s > bestScore) { bestScore = s; best = c; }
    }
    return bestScore >= 8 ? best : null;
  }
  function matchSmallTalk(n) {
    let bestKey = null, bestScore = 0;
    for (const key in smallTalkData) {
      const s = scoreAgainst(n, smallTalkData[key].keywords);
      if (s > bestScore) { bestScore = s; bestKey = key; }
    }
    return bestScore >= 8 ? bestKey : null;
  }
  function matchTopic(n) {
    let bestKey = null, bestScore = 0;
    for (const key of eventDataOrder) {
      const s = scoreAgainst(n, eventData[key].keywords);
      if (s > bestScore) { bestScore = s; bestKey = key; }
    }
    return bestScore >= 6 ? bestKey : null;
  }

  /* ---------------- rendering ---------------- */
  function clearEmptyState() {
    const empty = dom.chatLog.querySelector(".chat-log-empty");
    if (empty) empty.remove();
  }
  function scrollLogToBottom() {
    dom.chatLog.scrollTop = dom.chatLog.scrollHeight;
    scheduleLogFadeUpdate();
  }

  /* Older messages don't hard-cut at the top of the log — they dissolve
     (blur + fade) as they scroll up toward the robot's stage, which sits
     directly above. Distance is measured from each row's own bottom edge
     to the log's top edge, so the effect tracks scroll position exactly
     rather than looping on a timer. rAF-batched so scroll never triggers
     more than one recompute per frame. */
  const LOG_FADE_ZONE = 92;
  let logFadeRaf = null;
  function updateLogFade() {
    if (!dom.chatLog) return;
    const logRect = dom.chatLog.getBoundingClientRect();
    const rows = dom.chatLog.children;
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      if (!row.classList || !row.classList.contains("bubble-row")) continue;
      const dist = row.getBoundingClientRect().bottom - logRect.top;
      if (dist < LOG_FADE_ZONE) {
        const t = Math.max(0, Math.min(1, dist / LOG_FADE_ZONE));
        row.style.opacity = (0.05 + 0.95 * t).toFixed(3);
        row.style.filter = t >= 0.98 ? "" : `blur(${((1 - t) * 5).toFixed(2)}px)`;
      } else if (row.style.opacity || row.style.filter) {
        row.style.opacity = "";
        row.style.filter = "";
      }
    }
  }
  function scheduleLogFadeUpdate() {
    if (window.DRAPH_MOTION.reduced() || logFadeRaf) return;
    logFadeRaf = requestAnimationFrame(() => { logFadeRaf = null; updateLogFade(); });
  }

  function showEmptyState() {
    dom.chatLog.innerHTML = `<p class="chat-log-empty">Your conversation with DRAPH will appear here.<br>Ask about the Fest Date, Timings, Participants, Theme, or Smart Classroom.</p>`;
  }
  function addUserBubble(text) {
    clearEmptyState();
    const row = document.createElement("div");
    row.className = "bubble-row user";
    row.innerHTML = `<div class="bubble-avatar user-avatar">${ICONS.userAvatar}</div><div class="bubble">${escapeHtml(text)}</div>`;
    dom.chatLog.appendChild(row);
    scrollLogToBottom();
  }
  function addBotBubble(html, tag) {
    clearEmptyState();
    const row = document.createElement("div");
    row.className = "bubble-row bot";
    row.innerHTML = `<div class="bubble-avatar bot-avatar">${ICONS.botAvatar}</div><div class="bubble"><span class="bubble-tag">${escapeHtml(tag.toUpperCase())}</span>${html}</div>`;
    dom.chatLog.appendChild(row);
    scrollLogToBottom();
    return row;
  }
  function addBotThinkingBubble() {
    clearEmptyState();
    const row = document.createElement("div");
    row.className = "bubble-row bot";
    row.innerHTML = `<div class="bubble-avatar bot-avatar">${ICONS.botAvatar}</div><div class="bubble"><div class="typing-dots"><span></span><span></span><span></span></div><span class="thinking-note"></span></div>`;
    dom.chatLog.appendChild(row);
    scrollLogToBottom();
    return row;
  }

  function wrapCharsForTypewriter(rootEl) {
    const walker = document.createTreeWalker(rootEl, NodeFilter.SHOW_TEXT);
    const textNodes = [];
    let node;
    while ((node = walker.nextNode())) textNodes.push(node);
    const spans = [];
    for (const tn of textNodes) {
      const frag = document.createDocumentFragment();
      for (const ch of tn.textContent) {
        const span = document.createElement("span");
        span.className = "type-char";
        span.textContent = ch;
        frag.appendChild(span);
        spans.push(span);
      }
      tn.parentNode.replaceChild(frag, tn);
    }
    return spans;
  }

  function openExplainPanel(tag) {
    dom.explainPanel.classList.remove("dissolving");
    dom.explainTextInner.innerHTML = `<span class="bubble-tag"></span><div class="explain-content"></div>`;
    dom.explainTextInner.querySelector(".bubble-tag").textContent = tag.toUpperCase();
    void dom.explainPanel.offsetWidth;
    dom.explainPanel.classList.add("open");
  }

  function typewriterInto(html) {
    return new Promise((resolve) => {
      const contentEl = dom.explainTextInner.querySelector(".explain-content");
      contentEl.innerHTML = html;
      const spans = wrapCharsForTypewriter(contentEl);
      const cursor = document.createElement("span");
      cursor.className = "type-cursor";
      contentEl.appendChild(cursor);

      const total = spans.length;
      if (total === 0 || window.DRAPH_MOTION.reduced()) {
        spans.forEach((s) => s.classList.add("shown"));
        cursor.remove();
        resolve();
        return;
      }
      let i = 0, ticksSince = 0;
      function tick() {
        spans[i].classList.add("shown");
        if (spans[i].textContent.trim() !== "") {
          ticksSince++;
          if (ticksSince >= 2) { Audio_.playTick(); ticksSince = 0; }
        }
        i++;
        if (i % 4 === 0 || i >= total) {
          dom.explainTextInner.scrollTop = dom.explainTextInner.scrollHeight;
        }
        if (i < total) {
          setTimeout(tick, 22 + Math.random() * 14);
        } else {
          cursor.remove();
          resolve();
        }
      }
      tick();
    });
  }

  function dissolveExplainPanel() {
    return new Promise((resolve) => {
      dom.explainPanel.classList.add("dissolving");
      setTimeout(() => {
        dom.explainPanel.classList.remove("open", "dissolving");
        dom.explainTextInner.innerHTML = "";
        resolve();
      }, 420);
    });
  }

  function pulseNodeGrid() {
    dom.nodeGrid.classList.add("pulse-attention");
    setTimeout(() => dom.nodeGrid.classList.remove("pulse-attention"), 1000);
  }

  /* ---------------- delivery choreography ----------------
     `htmlOrPromise` may be a ready HTML string (Script Bot — instant,
     local) or a Promise that resolves to one (Chat Bot — a live API
     call). Either way the robot's rush-to-center plays immediately;
     the two just run concurrently, so a slow API reply doesn't add a
     visible stall on top of the animation, and a fast local answer
     isn't held back waiting on nothing. */
  async function deliverFullResponse(htmlOrPromise, tag) {
    Robot.reactAlert();
    const thinkingBubble = addBotThinkingBubble();
    Robot.setThinking(true);
    Audio_.playTick();

    // A local script-bot answer resolves instantly, so this never fires
    // for that path — it only shows up once a real network call (Chat
    // Bot) legitimately runs long, so a slow-but-working reply never
    // reads as a frozen/broken UI.
    const thinkingNote = thinkingBubble.querySelector(".thinking-note");
    const reassure1 = setTimeout(() => { if (thinkingNote) thinkingNote.textContent = "Still thinking…"; }, 4000);
    const reassure2 = setTimeout(() => { if (thinkingNote) thinkingNote.textContent = "Almost there…"; }, 11000);

    const [, html] = await Promise.all([Robot.rushToExplain(), Promise.resolve(htmlOrPromise)]);
    clearTimeout(reassure1); clearTimeout(reassure2);
    Robot.setThinking(false);

    thinkingBubble.remove();
    addBotBubble(html, tag);
    openExplainPanel(tag);

    const typingDone = typewriterInto(html);
    let speechDone = Promise.resolve();
    if (!Audio_.isMuted()) {
      speechDone = new Promise((resolve) => {
        // Start TTS generation immediately so cloud voice latency is hidden
        // behind the typewriter, but delay actual playback by ~2 seconds.
        Audio_.speak(html, {
          delayMs: 2000,
          onStart: () => { Robot.setSpeaking(true); },
          onBoundary: () => Robot.onSpeechBoundary(),
          onEnd: () => { Robot.setSpeaking(false); resolve(); }
        });
      });
    }
    await Promise.all([typingDone, speechDone, wait(1900)]);
    await wait(750);

    await dissolveExplainPanel();
    await Robot.returnToIdle();
    return html;
  }

  async function deliverLightResponse(html, tag) {
    Robot.reactAlert();
    addBotBubble(html, tag);
    if (!Audio_.isMuted()) {
      await new Promise((resolve) => {
        Robot.setSpeaking(true);
        Audio_.speak(html, { onBoundary: () => Robot.onSpeechBoundary(), onEnd: () => { Robot.setSpeaking(false); resolve(); } });
      });
    }
  }

  async function runCommand(action) {
    switch (action) {
      case "mute":
        setMuted(true);
        await deliverLightResponse("Voice muted — I'll still answer in text.", "DRAPH");
        break;
      case "unmute":
        setMuted(false);
        await deliverLightResponse("Voice is back on!", "DRAPH");
        break;
      case "stopSpeaking":
        Audio_.cancelSpeech();
        Robot.setSpeaking(false);
        addBotBubble("Okay, stopping.", "DRAPH");
        break;
      case "repeat":
        if (lastAnswer) await deliverFullResponse(lastAnswer.html, lastAnswer.tag);
        else await deliverLightResponse("I haven't said anything yet — ask me a question first!", "DRAPH");
        break;
      case "clearChat":
        dom.chatLog.innerHTML = "";
        showEmptyState();
        ChatBotAPI.resetConversation();
        lastAnswer = { html: welcomeMessage, tag: "DRAPH" };
        addBotBubble(welcomeMessage, "DRAPH");
        break;
      case "help":
        pulseNodeGrid();
        lastAnswer = {
          html: `Ask me about the <strong>Fest Date</strong>, <strong>Timings</strong>, <strong>Participants</strong>, <strong>Theme</strong> or the <strong>Smart Classroom</strong> — by typing, speaking, or tapping a card below. You can also say <em>"mute"</em>, <em>"repeat that"</em>, or <em>"clear chat"</em>. Try the <strong>Chat Bot</strong> toggle above the input for open-ended AI conversation.`,
          tag: "What I can do"
        };
        await deliverFullResponse(lastAnswer.html, lastAnswer.tag);
        break;
    }
  }

  /* ---------------- Chat Bot (live AI, via our own local proxy) ---------------- */
  function formatChatBotAnswer(rawText) {
    // Escape FIRST, then reintroduce only our own controlled tags — this
    // can never let anything the model outputs inject real markup.
    let safe = escapeHtml(rawText).trim();
    safe = safe.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    safe = safe.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, "$1<em>$2</em>");
    safe = safe.replace(/\n{2,}/g, "<br><br>").replace(/\n/g, "<br>");
    return safe || "I'm not sure how to answer that — could you try asking a different way?";
  }

  async function handleChatBotQuery(text) {
    const answerPromise = ChatBotAPI.ask(text)
      .then((raw) => formatChatBotAnswer(raw))
      .catch((err) => `Hmm, I ran into a problem — ${escapeHtml(err && err.message ? err.message : "please try again")}. You can also switch to Script Bot for the expo FAQ.`);
    const html = await deliverFullResponse(answerPromise, "DRAPH");
    lastAnswer = { html, tag: "DRAPH" };
  }

  async function handleUserQuery(rawText) {
    const text = rawText.trim();
    if (!text) return;
    addUserBubble(text);
    dom.userInput.value = "";

    const norm = normalize(text);
    const cmd = matchCommand(norm);
    if (cmd) { await runCommand(cmd.action); return; }

    if (botMode === "chat") { await handleChatBotQuery(text); return; }

    const stKey = matchSmallTalk(norm);
    if (stKey) { await deliverLightResponse(pickRandom(smallTalkData[stKey].responses), "DRAPH"); return; }

    const topicKey = matchTopic(norm);
    if (topicKey) {
      lastAnswer = { html: eventData[topicKey].content, tag: eventData[topicKey].label };
      await deliverFullResponse(lastAnswer.html, lastAnswer.tag);
      return;
    }

    lastAnswer = { html: pickRandom(fallbackResponses), tag: "DRAPH" };
    await deliverFullResponse(lastAnswer.html, lastAnswer.tag);
  }

  async function handleTopicDirect(key) {
    const d = eventData[key];
    addUserBubble(d.label);
    lastAnswer = { html: d.content, tag: d.label };
    await deliverFullResponse(d.content, d.label);
  }

  /* ---------------- node grid ---------------- */
  function renderNodeGrid() {
    dom.nodeGrid.innerHTML = eventDataOrder.map((key) => {
      const d = eventData[key];
      return `<button class="node-btn" data-topic="${key}" type="button">${ICONS[d.icon] || ""}<span>${escapeHtml(d.label)}</span></button>`;
    }).join("");
    dom.nodeGrid.querySelectorAll(".node-btn").forEach((btn) => {
      btn.addEventListener("click", () => handleTopicDirect(btn.dataset.topic));
    });
  }

  /* ---------------- mute ---------------- */
  function setMuted(v) {
    Audio_.setMuted(v);
    dom.muteToggle.classList.toggle("is-muted", v);
    dom.muteToggle.setAttribute("aria-pressed", String(v));
    dom.muteToggle.innerHTML = v ? ICONS.muted : ICONS.unmuted;
    dom.muteToggle.setAttribute("aria-label", v ? "Unmute DRAPH" : "Mute DRAPH");
    if (v) { Audio_.cancelSpeech(); Robot.setSpeaking(false); }
  }

  /* ---------------- mic ---------------- */
  function setMicStatus(text) {
    dom.micStatus.textContent = text;
    dom.micStatus.hidden = !text;
  }
  function initMic() {
    dom.micBtn.innerHTML = ICONS.mic;
    if (!Audio_.isSTTSupported()) {
      dom.micBtn.disabled = true;
      dom.micBtn.title = "Voice input isn't supported in this browser";
      return;
    }
    dom.micBtn.addEventListener("click", () => {
      Audio_.unlock();
      if (Audio_.isListening) { Audio_.stopListening(); return; }
      dom.micBtn.classList.add("listening");
      Audio_.startListening({
        onStart: () => setMicStatus("Listening…"),
        onResult: (transcript) => {
          setMicStatus("");
          dom.micBtn.classList.remove("listening");
          if (transcript && transcript.trim()) handleUserQuery(transcript);
        },
        onEnd: () => { dom.micBtn.classList.remove("listening"); },
        onError: (err) => {
          dom.micBtn.classList.remove("listening");
          if (err === "not-allowed" || err === "permission-denied" || err === "service-not-allowed") setMicStatus("Microphone permission needed.");
          else if (err === "audio-capture") setMicStatus("No microphone found.");
          else if (err === "no-speech") setMicStatus("Didn't catch that — try again.");
          else if (err === "network") setMicStatus("Voice input needs a network connection.");
          else if (err === "timeout") setMicStatus("Voice input didn't respond — check mic permission.");
          else if (err === "aborted") setMicStatus("");
          else if (err === "insecure") setMicStatus("Voice input needs https or localhost.");
          else if (err === "unsupported") setMicStatus("Voice input isn't supported here.");
          else setMicStatus("Voice input hit a snag — try again.");
          setTimeout(() => setMicStatus(""), 2600);
        }
      });
    });
  }

  /* ---------------- settings panel ---------------- */
  function applyTheme(themeClass) {
    document.body.classList.remove("theme-nebula", "theme-solaris", "theme-verdant");
    document.body.classList.add(themeClass);
    try { localStorage.setItem("draph_theme", themeClass); } catch (e) { /* ignore */ }
  }
  function initSettings() {
    dom.settingsToggle.innerHTML = ICONS.gear;

    // `inert` is the fix here, not just cosmetic: opacity/pointer-events
    // alone (how the panel is hidden visually) do NOT remove an element
    // from the Tab order, so a keyboard user could previously tab straight
    // into swatch/rate/motion controls while the panel was still closed
    // and invisible. `inert` removes the whole subtree from both the tab
    // order and the accessibility tree, while still letting the opacity/
    // transform CSS transition animate normally (unlike display:none).
    dom.settingsPanel.inert = true;
    function setSettingsOpen(open) {
      dom.settingsPanel.classList.toggle("open", open);
      dom.settingsPanel.inert = !open;
      dom.settingsToggle.setAttribute("aria-expanded", String(open));
      if (open) {
        const first = dom.settingsPanel.querySelector(".swatch-btn, .seg-btn, .toggle-switch");
        if (first) first.focus();
      }
    }
    dom.settingsToggle.setAttribute("aria-expanded", "false");
    dom.settingsToggle.addEventListener("click", () => setSettingsOpen(!dom.settingsPanel.classList.contains("open")));
    document.addEventListener("click", (e) => {
      if (!dom.settingsPanel.classList.contains("open")) return;
      if (dom.settingsPanel.contains(e.target) || dom.settingsToggle.contains(e.target)) return;
      setSettingsOpen(false);
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && dom.settingsPanel.classList.contains("open")) {
        setSettingsOpen(false);
        dom.settingsToggle.focus();
      }
    });

    const savedTheme = (() => { try { return localStorage.getItem("draph_theme"); } catch (e) { return null; } })() || "theme-nebula";
    applyTheme(savedTheme);
    dom.settingsPanel.querySelectorAll(".swatch-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.theme === savedTheme);
      btn.addEventListener("click", () => {
        applyTheme(btn.dataset.theme);
        dom.settingsPanel.querySelectorAll(".swatch-btn").forEach((b) => b.classList.toggle("active", b === btn));
      });
    });

    const savedRate = (() => { try { return localStorage.getItem("draph_speech_rate"); } catch (e) { return null; } })() || "1";
    Audio_.setSpeechRate(parseFloat(savedRate));
    dom.settingsPanel.querySelectorAll(".seg-btn[data-rate]").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.rate === savedRate);
      btn.addEventListener("click", () => {
        Audio_.setSpeechRate(parseFloat(btn.dataset.rate));
        dom.settingsPanel.querySelectorAll(".seg-btn[data-rate]").forEach((b) => b.classList.toggle("active", b === btn));
      });
    });

    const motionToggle = dom.motionToggle;
    const setMotionUI = (reduced) => motionToggle.classList.toggle("on", !reduced);
    setMotionUI(window.DRAPH_MOTION.reduced());
    motionToggle.addEventListener("click", () => {
      const currentlyFull = motionToggle.classList.contains("on");
      window.DRAPH_MOTION.setManual(currentlyFull); // was full -> now reduce
      setMotionUI(currentlyFull);
    });
  }

  /* ---------------- Script Bot / Chat Bot mode toggle ---------------- */
  function botModeUnavailableMessage() {
    if (!ChatBotAPI.isAvailable()) {
      return "Chat Bot needs the DRAPH server running (see the project's README for <code>server/server.py</code>) — Script Bot has you covered in the meantime!";
    }
    return "Chat Bot isn't set up on this server yet — it needs a Gemini API key (see the README). Script Bot works great either way!";
  }
  function setBotMode(mode) {
    if (mode === "chat" && !ChatBotAPI.isConfigured()) {
      addBotBubble(botModeUnavailableMessage(), "DRAPH");
      return;
    }
    if (mode === botMode) return;
    botMode = mode;
    dom.modeButtons.forEach((btn) => btn.classList.toggle("active", btn.dataset.mode === mode));
    dom.userInput.placeholder = mode === "chat" ? "Ask DRAPH anything…" : "Ask DRAPH about the expo…";
  }
  async function initModeToggle() {
    dom.modeButtons.forEach((btn) => {
      btn.addEventListener("click", () => setBotMode(btn.dataset.mode));
    });
    const chatBtn = dom.modeButtons.find((b) => b.dataset.mode === "chat");
    if (!chatBtn) return;
    chatBtn.classList.add("checking");
    const { configured } = await ChatBotAPI.checkHealth();
    chatBtn.classList.remove("checking");
    chatBtn.classList.toggle("unavailable", !configured);
    chatBtn.title = configured ? "Open AI conversation via Gemini" : botModeUnavailableMessage().replace(/<[^>]+>/g, "");
  }

  /* ---------------- public ---------------- */
  function init(refs) {
    dom = refs;
    dom.modeButtons = Array.from(refs.modeButtons || []);
    renderNodeGrid();
    initMic();
    initSettings();
    initModeToggle();
    setMuted(Audio_.isMuted());
    showEmptyState();

    dom.muteToggle.addEventListener("click", () => {
      Audio_.unlock();
      setMuted(!Audio_.isMuted());
    });

    dom.chatLog.addEventListener("scroll", scheduleLogFadeUpdate, { passive: true });
    window.addEventListener("resize", scheduleLogFadeUpdate, { passive: true });

    dom.inputForm.addEventListener("submit", (e) => {
      e.preventDefault();
      Audio_.unlock();
      const text = dom.userInput.value;
      if (text.trim()) handleUserQuery(text);
    });
  }

  function showWelcome() {
    lastAnswer = { html: welcomeMessage, tag: "DRAPH" };
    addBotBubble(welcomeMessage, "DRAPH");
    if (!Audio_.isMuted()) {
      Robot.setSpeaking(true);
      Audio_.speak(welcomeMessage, { onBoundary: () => Robot.onSpeechBoundary(), onEnd: () => Robot.setSpeaking(false) });
    }
  }

  return { init, showWelcome };
})();