/* ============================================================
   DRAPH — background.js
   All decorative backdrop effects. Nothing here is interactive
   or focusable (aria-hidden), everything pauses when the tab is
   hidden, and heavy bits scale down under prefers-reduced-motion
   or on small/low-power viewports. Z-index is intentionally low
   (see --z-backdrop in base.css) — the backdrop must never sit
   above the robot or any interactive control.
   ============================================================ */

const Background = (() => {

  let visible = true;
  document.addEventListener("visibilitychange", () => { visible = !document.hidden; });

  // Cheap, synchronous heuristic for "this looks like modest hardware" —
  // low logical core count is a reasonable proxy without the cost/flakiness
  // of a runtime self-benchmark. Scales decorative density down; never
  // removes functionality.
  const lowPower = (navigator.hardwareConcurrency || 4) <= 2;
  const densityScale = lowPower ? 0.6 : 1;

  /* ---------------- hex texture (CSS custom property, data-URI tile) ---------------- */
  function buildHexTile() {
    const s = `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="111" viewBox="0 0 64 111">
      <polygon points="32,0 64,18.5 64,55.5 32,74 0,55.5 0,18.5" fill="none" stroke="#3FE8FF" stroke-width="1"/>
      <polygon points="32,37 64,55.5 64,92.5 32,111 0,92.5 0,55.5" fill="none" stroke="#3FE8FF" stroke-width="1"/>
    </svg>`;
    const uri = `url("data:image/svg+xml,${encodeURIComponent(s)}")`;
    document.documentElement.style.setProperty("--hex-pattern", uri);
  }

  /* ---------------- procedural circuit trace paths ---------------- */
  function buildCircuitSvg(svgEl) {
    const W = 1200, H = 800;
    svgEl.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svgEl.setAttribute("preserveAspectRatio", "xMidYMid slice");

    const traceCount = Math.max(4, Math.round(7 * densityScale));
    let tracesHtml = "";
    let nodesHtml = "";
    const rand = (a, b) => a + Math.random() * (b - a);
    const pick = (arr) => arr[(Math.random() * arr.length) | 0];

    for (let i = 0; i < traceCount; i++) {
      // a simple PCB-style orthogonal path: random walk of horizontal/vertical segments
      let x = rand(0, W), y = rand(0, H);
      let d = `M${x.toFixed(0)},${y.toFixed(0)}`;
      const segs = 3 + ((Math.random() * 3) | 0);
      for (let s = 0; s < segs; s++) {
        const horizontal = Math.random() > 0.5;
        const len = rand(60, 220);
        if (horizontal) x += Math.random() > 0.5 ? len : -len;
        else y += Math.random() > 0.5 ? len : -len;
        x = Math.max(20, Math.min(W - 20, x));
        y = Math.max(20, Math.min(H - 20, y));
        d += ` L${x.toFixed(0)},${y.toFixed(0)}`;
      }
      const cls = pick(["trace", "trace trace-2", "trace trace-3", "trace trace-4", "trace trace-5"]);
      tracesHtml += `<path class="${cls}" d="${d}"/>`;
      if (Math.random() > 0.4) nodesHtml += `<circle class="node" cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="4"/>`;
    }
    // scattered standalone junction nodes for extra texture
    for (let i = 0; i < 10; i++) {
      nodesHtml += `<circle class="node" cx="${rand(0, W).toFixed(0)}" cy="${rand(0, H).toFixed(0)}" r="3.4"/>`;
    }

    svgEl.innerHTML = `
      <path class="entrance-arch" d="M${W*0.5-260},${H+40} Q${W*0.5-260},${H*0.35} ${W*0.5},${H*0.1} Q${W*0.5+260},${H*0.35} ${W*0.5+260},${H+40}"/>
      <g class="circuit-paths">${tracesHtml}</g>
      <g class="circuit-nodes">${nodesHtml}</g>
    `;
  }

  /* ---------------- neural network canvas ---------------- */
  class NeuralField {
    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext("2d", { alpha: true });
      this.nodes = [];
      this.pulses = [];
      this.dpr = Math.min(window.devicePixelRatio || 1, lowPower ? 1.3 : 2);
      this.raf = null;
      this.lastT = 0;
      this.resize();
    }
    resize() {
      const w = window.innerWidth, h = window.innerHeight;
      this.canvas.width = Math.round(w * this.dpr);
      this.canvas.height = Math.round(h * this.dpr);
      this.canvas.style.width = w + "px";
      this.canvas.style.height = h + "px";
      this.ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      this.w = w; this.h = h;

      const area = w * h;
      const targetCount = Math.max(10, Math.min(38, Math.round((area / 34000) * densityScale)));
      this.nodes = Array.from({ length: targetCount }, () => this.spawnNode());
    }
    spawnNode() {
      return {
        x: Math.random() * this.w,
        y: Math.random() * this.h,
        vx: (Math.random() - 0.5) * 0.18,
        vy: (Math.random() - 0.5) * 0.18,
        r: 1 + Math.random() * 1.6,
        hueAlt: Math.random() > 0.72
      };
    }
    maybeSpawnPulse() {
      if (this.nodes.length < 2 || Math.random() > 0.02) return;
      const a = this.nodes[(Math.random() * this.nodes.length) | 0];
      const b = this.nodes[(Math.random() * this.nodes.length) | 0];
      const dx = a.x - b.x, dy = a.y - b.y;
      if (a === b || Math.hypot(dx, dy) > 260) return;
      this.pulses.push({ a, b, t: 0, alt: Math.random() > 0.5 });
    }
    step(dt) {
      const { ctx, w, h } = this;
      ctx.clearRect(0, 0, w, h);

      for (const n of this.nodes) {
        n.x += n.vx * dt; n.y += n.vy * dt;
        if (n.x < -20) n.x = w + 20; if (n.x > w + 20) n.x = -20;
        if (n.y < -20) n.y = h + 20; if (n.y > h + 20) n.y = -20;
      }

      // connections
      ctx.lineWidth = 1;
      for (let i = 0; i < this.nodes.length; i++) {
        for (let j = i + 1; j < this.nodes.length; j++) {
          const a = this.nodes[i], b = this.nodes[j];
          const dx = a.x - b.x, dy = a.y - b.y;
          const dist = Math.hypot(dx, dy);
          if (dist < 130) {
            const alpha = (1 - dist / 130) * 0.16;
            ctx.strokeStyle = `rgba(63,232,255,${alpha})`;
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
      }
      // nodes
      for (const n of this.nodes) {
        ctx.beginPath();
        ctx.fillStyle = n.hueAlt ? "rgba(255,79,209,0.55)" : "rgba(63,232,255,0.55)";
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fill();
      }
      // pulses
      this.maybeSpawnPulse();
      for (let i = this.pulses.length - 1; i >= 0; i--) {
        const p = this.pulses[i];
        p.t += dt * 0.0018;
        if (p.t >= 1) { this.pulses.splice(i, 1); continue; }
        const x = p.a.x + (p.b.x - p.a.x) * p.t;
        const y = p.a.y + (p.b.y - p.a.y) * p.t;
        ctx.beginPath();
        ctx.fillStyle = p.alt ? "rgba(255,79,209,0.9)" : "rgba(63,232,255,0.9)";
        ctx.shadowColor = p.alt ? "rgba(255,79,209,0.9)" : "rgba(63,232,255,0.9)";
        ctx.shadowBlur = 6;
        ctx.arc(x, y, 1.8, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    }
    loop(t) {
      if (!window.DRAPH_MOTION.reduced() && visible) {
        const dt = this.lastT ? Math.min(48, t - this.lastT) : 16;
        this.lastT = t;
        this.step(dt);
      } else {
        this.lastT = 0;
      }
      this.raf = requestAnimationFrame(this.loop.bind(this));
    }
    start() { if (!this.raf) this.raf = requestAnimationFrame(this.loop.bind(this)); }
  }

  /* ---------------- drifting code fragments ---------------- */
  const CODE_SNIPPETS = [
    "const draph = new Hologram();", "AI.EXPO_2026.init()", "> booting neural_core...",
    "01001001 01010100", "SRMJV::AI_EXPO", "model.predict(future)",
    "while(curious){ learn(); }", "// नमस्ते from DRAPH", "sensor.calibrate()",
    "0x4A1F 0x3E90", "render(hologram)", "for student in expo:",
    "class Robot(Hologram):", "def float(self): ...", "signal.emit('ready')",
    "<AI Expo 2026–27/>", "voice.synthesize(text)", "np.array([1,1,2,3,5,8])",
    "listen() -> transcript", "system.status = 'ONLINE'"
  ];

  function spawnCodeFrag(layer) {
    const el = document.createElement("span");
    const alt = Math.random() > 0.55;
    el.className = "code-frag" + (alt ? " frag-alt" : "");
    el.textContent = CODE_SNIPPETS[(Math.random() * CODE_SNIPPETS.length) | 0];
    const dur = 16 + Math.random() * 14;
    const twinkleDur = 3 + Math.random() * 3;
    el.style.left = Math.random() * 96 + "%";
    el.style.animationDuration = `${dur}s, ${twinkleDur}s`;
    el.style.animationDelay = `${-Math.random() * dur}s, ${-Math.random() * twinkleDur}s`;
    layer.appendChild(el);
    return el;
  }

  function initCodeDrift(layer) {
    if (window.DRAPH_MOTION.reduced()) return;
    const area = window.innerWidth * window.innerHeight;
    const count = Math.max(5, Math.min(18, Math.round((area / 62000) * densityScale)));
    for (let i = 0; i < count; i++) spawnCodeFrag(layer);
    // periodically recycle a random fragment so the field stays fresh forever
    setInterval(() => {
      if (!visible) return;
      const kids = layer.children;
      if (!kids.length) return;
      const el = kids[(Math.random() * kids.length) | 0];
      el.remove();
      spawnCodeFrag(layer);
    }, 2600);
  }

  /* ---------------- pointer parallax (fine pointers only) ---------------- */
  function initParallax(el) {
    if (lowPower || window.DRAPH_MOTION.reduced() || !window.matchMedia("(pointer: fine)").matches) return;
    let tx = 0, ty = 0, cx = 0, cy = 0, raf = null;
    window.addEventListener("pointermove", (e) => {
      tx = (e.clientX / window.innerWidth - 0.5) * 2;
      ty = (e.clientY / window.innerHeight - 0.5) * 2;
    }, { passive: true });
    function loop() {
      if (visible) {
        cx += (tx - cx) * 0.04;
        cy += (ty - cy) * 0.04;
        el.style.transform = `translate3d(${(-cx * 10).toFixed(2)}px, ${(-cy * 8).toFixed(2)}px, 0)`;
      }
      raf = requestAnimationFrame(loop);
    }
    loop();
  }

  function init() {
    buildHexTile();
    const circuitSvg = document.getElementById("circuitSvg");
    if (circuitSvg) buildCircuitSvg(circuitSvg);

    const codeLayer = document.getElementById("codeDriftLayer");
    if (codeLayer) initCodeDrift(codeLayer);

    const parallaxEl = document.querySelector(".backdrop-parallax");
    if (parallaxEl) initParallax(parallaxEl);

    const canvas = document.getElementById("neuralCanvas");
    let field = null;
    if (canvas) {
      field = new NeuralField(canvas);
      field.start();
      let resizeT = null;
      window.addEventListener("resize", () => {
        clearTimeout(resizeT);
        resizeT = setTimeout(() => field.resize(), 150);
      });
    }

    return { field };
  }

  return { init };
})();
