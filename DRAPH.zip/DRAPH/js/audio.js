/* ============================================================
   DRAPH — audio.js
   Sound effects (WebAudio, for sample-accurate low-latency
   retriggering) + boot audio (plain <audio>, simple loop/one-shot)
   + text-to-speech (chunked for natural-sounding prosody) +
   speech-to-text (voice commands / voice questions).
   ============================================================ */

const Audio_ = (() => {

  let muted = false;
  try { muted = localStorage.getItem("draph_muted") === "1"; } catch (e) { /* ignore */ }

  let speedMultiplier = 1;
  try {
    const saved = localStorage.getItem("draph_speech_rate");
    if (saved) speedMultiplier = parseFloat(saved);
  } catch (e) { /* ignore */ }

  /* ---------------- WebAudio: tick sound ---------------- */
  let actx = null, masterGain = null, tickBuffer = null;
  let lastTickAt = 0;

  // Each new speech run gets a token so delayed starts can be cancelled
  // cleanly when the user mutes/stops/repeats a response.
  let speechRunId = 0;

  function ensureContext() {
    if (!actx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      actx = new AC();
      masterGain = actx.createGain();
      masterGain.gain.value = muted ? 0 : 1;
      masterGain.connect(actx.destination);
    }
    if (actx.state === "suspended") actx.resume().catch(() => {});
    return actx;
  }

  async function loadTickBuffer() {
    try {
      const ctx = ensureContext();
      if (!ctx) return;
      const res = await fetch("assets/typing-tick.wav");
      const arr = await res.arrayBuffer();
      tickBuffer = await ctx.decodeAudioData(arr);
    } catch (e) { tickBuffer = null; }
  }

  function playTick() {
    if (muted || !tickBuffer || !actx) return;
    const now = performance.now();
    if (now - lastTickAt < 50) return; // defensive throttle
    lastTickAt = now;
    const src = actx.createBufferSource();
    src.buffer = tickBuffer;
    src.playbackRate.value = 1 + (Math.random() * 2 - 1) * 0.13;
    const g = actx.createGain();
    // Keep the typing VFX audible but clearly underneath the spoken voice.
    g.gain.value = 0.05 + Math.random() * 0.08;
    src.connect(g); g.connect(masterGain);
    src.start();
  }

  /* ---------------- boot audio (intro loop + intro-end chime) ---------------- */
  let introEl = null, introEndEl = null;

  function setupBootAudio() {
    introEl = new Audio("assets/intro.wav");
    introEl.loop = true; introEl.volume = 0.55; introEl.muted = muted;
    introEndEl = new Audio("assets/intro_end.wav");
    introEndEl.volume = 0.7; introEndEl.muted = muted;
  }
  function playIntroLoop() {
    if (!introEl) return;
    introEl.currentTime = 0;
    if (!muted) introEl.play().catch(() => {});
  }
  function stopIntroLoop() {
    if (!introEl) return;
    introEl.pause(); introEl.currentTime = 0;
  }
  function playIntroEnd() {
    if (!introEndEl) return;
    introEndEl.currentTime = 0;
    if (!muted) introEndEl.play().catch(() => {});
  }

  /* ---------------- mute ---------------- */
  function setMuted(v) {
    muted = v;
    if (masterGain) masterGain.gain.value = muted ? 0 : 1;
    if (introEl) introEl.muted = muted;
    if (introEndEl) introEndEl.muted = muted;
    if (muted) cancelSpeech();
    try { localStorage.setItem("draph_muted", muted ? "1" : "0"); } catch (e) { /* ignore */ }
  }
  function isMuted() { return muted; }

  function setSpeechRate(mult) {
    speedMultiplier = mult;
    try { localStorage.setItem("draph_speech_rate", String(mult)); } catch (e) { /* ignore */ }
  }

  function unlock() {
    ensureContext();
    if (!tickBuffer) loadTickBuffer();
  }

  /* ---------------- text-to-speech ---------------- */
  const NATURAL_HINTS = ["natural", "neural", "online", "premium", "enhanced", "plus",
    "aria", "jenny", "guy", "ryan", "sonia", "libby", "emma", "ava", "samantha",
    "karen", "moira", "tessa", "google", "wavenet"];
  const AVOID_HINTS = ["whisper", "zarvox", "trinoids", "bells", "bad news", "bahh",
    "boing", "bubbles", "cellos", "deranged", "hysterical", "pipe organ", "albert",
    "fred", "junior", "kathy", "organ", "rocko", "superstar", "bad", "wobble"];

  let cachedVoices = [];
  function refreshVoices() {
    if ("speechSynthesis" in window) cachedVoices = window.speechSynthesis.getVoices() || [];
  }
  if ("speechSynthesis" in window) {
    refreshVoices();
    window.speechSynthesis.onvoiceschanged = refreshVoices;
  }
  function scoreVoice(v) {
    const n = v.name.toLowerCase();
    let score = 0;
    if (v.lang && v.lang.toLowerCase().startsWith("en")) score += 5;
    if (v.lang && v.lang.toLowerCase() === "en-in") score += 2;
    for (const h of NATURAL_HINTS) if (n.includes(h)) score += 4;
    for (const h of AVOID_HINTS) if (n.includes(h)) score -= 9;
    if (v.localService === false) score += 1;
    return score;
  }
  function chosenVoice() {
    if (!cachedVoices.length) refreshVoices();
    if (!cachedVoices.length) return null;
    let best = cachedVoices[0], bestScore = -Infinity;
    for (const v of cachedVoices) {
      const s = scoreVoice(v);
      if (s > bestScore) { bestScore = s; best = v; }
    }
    return best;
  }

  function stripTags(html) {
    return html
      .replace(/<br\s*\/?>/gi, ". ")
      .replace(/<\/(p|li|div)>/gi, ". ")
      .replace(/<[^>]+>/g, "")
      .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&")
      .replace(/&#39;/g, "'").replace(/&quot;/g, '"')
      .replace(/\p{Extended_Pictographic}/gu, "")
      .replace(/\s+/g, " ").trim();
  }
  function extractEmphasized(html) {
    const set = new Set();
    const re = /<(strong|b|em)[^>]*>(.*?)<\/\1>/gi;
    let m;
    while ((m = re.exec(html))) {
      const t = stripTags(m[2]).trim().toLowerCase();
      if (t) set.add(t);
    }
    return set;
  }
  function applyPronunciation(text) {
    return text
      .replace(/\bSr\.\s*Sec\./gi, "Senior Secondary")
      .replace(/\bSRMJV\b/g, "S R M J V")
      .replace(/\bAI\b/g, "A I")
      // "2026-27"-style abbreviated year ranges get read digit-by-digit by
      // a lot of TTS engines (the dash + 2-digit tail isn't a pattern their
      // number normalizer recognizes) — spell the second year out in full
      // ("2026 to 2027") so it reads as two ordinary years instead.
      .replace(/(\d{4})\s*[\u2013\u2014-]\s*(\d{2})\b/g, (m, y1, y2) => `${y1} to ${y1.slice(0, 2)}${y2}`);
  }
  function splitSentences(text) {
    const parts = text.match(/[^.!?]+[.!?]*/g) || (text ? [text] : []);
    return parts.map((s) => s.trim()).filter(Boolean);
  }
  function jitter(amount) { return 1 + (Math.random() * 2 - 1) * amount; }

  let activeUtterances = [];
  function cancelSpeech() {
    speechRunId++;
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    activeUtterances = [];
    if (activeCloudAudio) { try { activeCloudAudio.pause(); } catch (e) { /* ignore */ } activeCloudAudio = null; }
  }

  /* ---------------- natural voice: Gemini TTS via our own server,
     with the browser's built-in voice as an automatic fallback ---------------- */
  let cloudTTSKnownUnavailable = false;
  let activeCloudAudio = null;

  async function tryCloudSpeak(plainText, { onStart, onEnd, delayMs = 0, runId, startedAt }) {
    if (cloudTTSKnownUnavailable) return false;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);
    try {
      const res = await fetch("/api/speak", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: plainText }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (res.status === 503) { cloudTTSKnownUnavailable = true; return false; } // not configured — stop trying this session
      if (!res.ok) return false; // could be transient (rate limit, hiccup) — try again next time
      const blob = await res.blob();
      if (!blob || blob.size < 200) return false;

      const url = URL.createObjectURL(blob);
      const el = new window.Audio(url);
      activeCloudAudio = el;
      let started = false;
      el.onplay = () => { if (!started) { started = true; if (onStart) onStart(); } };
      const cleanup = () => { URL.revokeObjectURL(url); if (activeCloudAudio === el) activeCloudAudio = null; };
      el.onended = () => { cleanup(); if (onEnd) onEnd(); };
      el.onerror = cleanup;

      // TTS generation starts immediately, but playback waits until the
      // requested offset from the moment speak() was called. This keeps
      // the natural voice from being held hostage by the full typewriter
      // animation, while still giving the text/typing VFX a short lead-in.
      const elapsed = performance.now() - startedAt;
      const remainingDelay = Math.max(0, delayMs - elapsed);
      if (remainingDelay > 0) await new Promise((resolve) => setTimeout(resolve, remainingDelay));
      if (runId !== speechRunId) { cleanup(); return true; }

      await el.play();
      return true;
    } catch (e) {
      clearTimeout(timeoutId);
      return false;
    }
  }

  async function speak(html, { onStart, onEnd, onBoundary, delayMs = 0 } = {}) {
    if (muted || !html) { if (onEnd) onEnd(); return; }
    cancelSpeech();
    const runId = speechRunId;
    const speechRunStartedAt = performance.now();
    const plain = applyPronunciation(stripTags(html));
    if (!plain) { if (onEnd) onEnd(); return; }

    const usedCloud = await tryCloudSpeak(plain, { onStart, onEnd, delayMs, runId, startedAt: speechRunStartedAt });
    if (usedCloud) return;

    const elapsed = performance.now() - speechRunStartedAt;
    const remainingDelay = Math.max(0, delayMs - elapsed);
    if (remainingDelay > 0) await new Promise((resolve) => setTimeout(resolve, remainingDelay));
    if (runId !== speechRunId) return;
    speakBrowserNative(html, { onStart, onEnd, onBoundary });
  }

  function speakBrowserNative(html, { onStart, onEnd, onBoundary } = {}) {
    if (!("speechSynthesis" in window)) { if (onEnd) onEnd(); return; }
    const emphasized = extractEmphasized(html);
    const plain = applyPronunciation(stripTags(html));
    const chunks = splitSentences(plain);
    if (!chunks.length) { if (onEnd) onEnd(); return; }

    const voice = chosenVoice();
    let remaining = chunks.length;
    let started = false;

    chunks.forEach((chunk) => {
      const u = new SpeechSynthesisUtterance(chunk);
      if (voice) u.voice = voice;
      const isEmph = [...emphasized].some((e) => e && chunk.toLowerCase().includes(e));
      u.rate = Math.min(1.35, Math.max(0.7, (isEmph ? 0.92 : 1) * jitter(0.045) * speedMultiplier));
      u.pitch = Math.min(1.4, Math.max(0.7, (isEmph ? 1.05 : 1) * jitter(0.035)));
      u.volume = 1;
      u.onstart = () => { if (!started) { started = true; if (onStart) onStart(); } };
      u.onboundary = () => { if (onBoundary) onBoundary(); };
      u.onend = () => { remaining--; if (remaining <= 0 && onEnd) onEnd(); };
      u.onerror = () => { remaining--; if (remaining <= 0 && onEnd) onEnd(); };
      activeUtterances.push(u);
      window.speechSynthesis.speak(u);
    });
  }

  /* ---------------- speech-to-text (voice input) ---------------- */
  let recognition = null;
  let recognizing = false;
  let watchdogTimer = null;

  function isSTTSupported() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  }
  function isSecureForSTT() {
    // Chromium treats file:// and localhost as secure contexts too.
    return window.isSecureContext || location.protocol === "file:" || location.hostname === "localhost";
  }
  function startListening({ onStart, onResult, onEnd, onError } = {}) {
    if (!isSTTSupported()) { if (onError) onError("unsupported"); return; }
    if (!isSecureForSTT()) { if (onError) onError("insecure"); return; }
    if (recognizing) return;

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    try { recognition = new SR(); } catch (e) { if (onError) onError("init-failed"); return; }
    recognition.lang = "en-IN";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.continuous = false;

    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true; recognizing = false;
      clearTimeout(watchdogTimer);
      if (onEnd) onEnd();
    };

    recognition.onstart = () => { if (onStart) onStart(); };
    recognition.onresult = (e) => {
      const transcript = e.results && e.results[0] && e.results[0][0] ? e.results[0][0].transcript : "";
      if (onResult) onResult(transcript);
    };
    recognition.onerror = (e) => {
      if (onError) onError(e.error || "unknown");
      finish();
    };
    recognition.onend = finish;

    // Set BEFORE calling start() (not inside onstart) and the watchdog
    // starts from the same moment, on purpose: some browsers/environments
    // never fire onstart at all while a permission prompt sits unanswered
    // (confirmed directly — a bare SpeechRecognition().start() produced no
    // event whatsoever for several seconds under a blocked-permission
    // context), which previously meant the watchdog scheduled *inside*
    // onstart would simply never exist, and the mic button could get
    // stuck showing "listening" forever with no recovery at all. Starting
    // the clock at the actual start() call covers that case too, not just
    // "started but then nothing happened."
    recognizing = true;
    watchdogTimer = setTimeout(() => {
      try { recognition.stop(); } catch (e) { /* ignore */ }
      if (!settled && onError) onError("timeout");
      finish();
    }, 12000);

    try { recognition.start(); } catch (e) { if (onError) onError("start-failed"); finish(); }
  }
  function stopListening() {
    if (recognition && recognizing) { try { recognition.stop(); } catch (e) { /* ignore */ } }
  }

  function init() {
    setupBootAudio();
  }

  return {
    init, unlock,
    setMuted, isMuted, setSpeechRate,
    playIntroLoop, stopIntroLoop, playIntroEnd,
    playTick, loadTickBuffer,
    speak, cancelSpeech,
    isSTTSupported, startListening, stopListening,
    get isListening() { return recognizing; }
  };
})();