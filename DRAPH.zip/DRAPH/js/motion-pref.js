/* ============================================================
   DRAPH — motion-pref.js  (load this FIRST, before robot/background/cursor)
   A single live-readable "should motion be reduced?" flag that
   respects the OS-level prefers-reduced-motion setting by default,
   but can be overridden from the in-app settings panel ("Calm
   Mode") without a page reload. Other modules call
   window.DRAPH_MOTION.reduced() instead of freezing the media
   query result at load time, so the toggle actually takes effect.
   ============================================================ */
window.DRAPH_MOTION = (() => {
  let manual = null; // null = no override; true/false = forced
  try {
    const saved = localStorage.getItem("draph_reduce_motion");
    if (saved === "1") manual = true;
    if (saved === "0") manual = false;
  } catch (e) { /* ignore */ }

  const mq = window.matchMedia ? window.matchMedia("(prefers-reduced-motion: reduce)") : null;

  function reduced() { return manual !== null ? manual : !!(mq && mq.matches); }
  function setManual(v) {
    manual = v;
    try { localStorage.setItem("draph_reduce_motion", v ? "1" : "0"); } catch (e) { /* ignore */ }
    document.body.classList.toggle("calm-mode", reduced());
  }
  function isOverridden() { return manual !== null; }

  document.addEventListener("DOMContentLoaded", () => {
    document.body.classList.toggle("calm-mode", reduced());
  });

  return { reduced, setManual, isOverridden };
})();
