/* ============================================================
   DRAPH — AI EXPO 2026-27 — CONTENT
   ------------------------------------------------------------
   This is the ONE file you need to edit to make DRAPH speak the
   real facts about your event. Nothing here needs to change for
   the app to work — everything below already renders correctly
   as friendly "details coming soon" placeholders.

   HOW MATCHING WORKS (plain-English version):
   When someone types or says something, DRAPH checks it against
   three layers, in this order, and answers with the first good
   match:
     1) COMMANDS       — "mute", "repeat that", "clear chat"...
     2) SMALL TALK      — "hi", "thanks", "who are you"...
     3) EVENT TOPICS     — the 5 cards below (date, timings, ...)
   If nothing scores above zero, DRAPH uses a fallbackResponse.
   Add as many keywords/synonyms as you like to any list — lower-
   case, no punctuation. Longer/more specific phrases score higher
   than single common words, so it's safe to add short ones too.
   HTML is allowed inside "content" (br, strong, em, ul/li).
   ============================================================ */

const EVENT_NAME = "AI Expo 2026–27";
const SCHOOL_NAME = "Sri R.M. Jain Vidhyashram Sr. Sec. School";
const SCHOOL_SHORT = "SRMJV";
const BOT_NAME = "DRAPH";

/* ---------------------------------------------------------------
   1) EVENT TOPICS — shown as quick-tap chips + matched by keyword
   --------------------------------------------------------------- */
const eventData = {

  festDate: {
    id: "N-01",
    label: "Fest Date",
    icon: "calendar",
    keywords: [
      "date", "dates", "when", "day", "days", "schedule date", "which day",
      "held on", "happening on", "conducted on", "when is it", "when is the expo"
    ],
    content: `
      <strong>📅 Fest Date — details coming soon.</strong><br><br>
      We're finalising the exact date for the <strong>${EVENT_NAME}</strong>
      — ${SCHOOL_SHORT}'s first-ever AI Expo. Check back here closer to the
      date, or ask a teacher-in-charge for the latest.
    `
  },

  timings: {
    id: "N-02",
    label: "Timings",
    icon: "clock",
    keywords: [
      "time", "timing", "timings", "hours", "start", "end", "opens", "closes",
      "opening time", "closing time", "what time", "duration", "how long"
    ],
    content: `
      <strong>⏰ Timings — details coming soon.</strong><br><br>
      Reporting time, session slots and the closing time for the
      <strong>${EVENT_NAME}</strong> will be published here once confirmed.
    `
  },

  participants: {
    id: "N-03",
    label: "Participants",
    icon: "users",
    keywords: [
      "participants", "who can come", "students", "schools", "eligibility",
      "who can participate", "which schools", "grades", "classes",
      "age group", "teams", "registration", "sign up", "signup", "visitors"
    ],
    content: `
      <strong>🧑‍🤝‍🧑 Participants — details coming soon.</strong><br><br>
      Which grades and teams are taking part in <strong>${EVENT_NAME}</strong>,
      and how visitors can register, will appear here soon.
    `
  },

  theme: {
    id: "N-04",
    label: "Theme",
    icon: "spark",
    keywords: [
      "theme", "topic", "concept", "focus area", "subject",
      "what is it about", "about the expo", "what is the theme", "purpose"
    ],
    content: `
      <strong>✨ Theme — details coming soon.</strong><br><br>
      The central theme of ${SCHOOL_SHORT}'s first dedicated
      <strong>${EVENT_NAME}</strong> will be described here — the big ideas
      in artificial intelligence the exhibits will explore.
    `
  },

  smartClassroom: {
    id: "N-05",
    label: "Smart Classroom",
    icon: "monitor",
    keywords: [
      "smart classroom", "smart class", "classroom", "tech lab",
      "smart room", "digital classroom", "smart classrooms", "smart labs"
    ],
    content: `
      <strong>🖥️ Smart Classroom — details coming soon.</strong><br><br>
      What's on display at the Smart Classroom showcase during the
      <strong>${EVENT_NAME}</strong> will be added here.
    `
  }
};

/* Order the quick-tap chips are displayed in */
const eventDataOrder = ["festDate", "timings", "participants", "theme", "smartClassroom"];

/* ---------------------------------------------------------------
   2) VOICE COMMANDS — work by typing OR speaking, checked first
   --------------------------------------------------------------- */
const commandData = [
  { action: "mute", keywords: ["mute", "mute yourself", "silence yourself", "go silent", "turn off your voice", "voice off"] },
  { action: "unmute", keywords: ["unmute", "voice on", "turn on your voice", "speak again", "unmute yourself"] },
  { action: "stopSpeaking", keywords: ["stop talking", "stop speaking", "be quiet now", "shush", "pause"] },
  { action: "repeat", keywords: ["repeat that", "say that again", "can you repeat that", "repeat please", "say it again", "come again"] },
  { action: "clearChat", keywords: ["clear chat", "clear the chat", "clear history", "reset chat", "start over", "new conversation"] },
  { action: "help", keywords: ["help", "what can you do", "what can i ask", "what can i ask you", "how do i use this", "show topics", "show me topics", "what can you help with"] }
];

/* ---------------------------------------------------------------
   3) SMALL TALK — gives DRAPH a bit of personality beyond the FAQ
   --------------------------------------------------------------- */
const smallTalkData = {
  greeting: {
    keywords: ["hi", "hello", "hey", "hey draph", "hi draph", "good morning", "good afternoon", "good evening", "namaste", "yo", "vanakkam", "greetings", "salutations", "vandanam", "bonjour", "hola", "ciao", "konnichiwa", "salaam", "shalom"],
    responses: [
      `Hey there! 👋 I'm ${BOT_NAME}. Ask me about the ${EVENT_NAME} — the date, timings, participants, theme or the Smart Classroom.`,
      `Hello! Welcome to ${SCHOOL_SHORT}'s first-ever AI Expo. What would you like to know?`,
      `Hi! Great to see you here. Tap a topic below or just ask me anything about the expo.`
    ]
  },
  thanks: {
    keywords: ["thank you", "thanks", "thank you draph", "thanks a lot", "appreciate it", "thanks draph", "nanri", "dhanyavaad", "gracias", "merci", "dhan-yavad", "shukriya", "arigato", "grazie", "danke", "obrigado", "spasibo", "terima kasih"],
    responses: [
      "You're welcome! Anything else you'd like to know about the expo?",
      "Happy to help! Let me know if you have more questions.",
      "Anytime! That's what I'm here for."
    ]
  },
  howAreYou: {
    keywords: ["how are you", "how are you doing", "how you doing", "how do you feel", "you good", "are you okay", "are you fine", "how's it going", "how's everything", "how's life", "how's your day", "eppidi irukkirathu"],
    responses: [
      "Running at full charge and glad to be talking with you! How can I help?",
      "All circuits nominal! Ready to tell you all about the expo.",
      "Feeling bright and holographic, thanks for asking! What can I help with?"
    ]
  },
  whoAreYou: {
    keywords: ["who are you", "what are you", "tell me about yourself", "your name", "what is draph", "what does draph mean"],
    responses: [
      `I'm ${BOT_NAME} — the holographic guide for ${SCHOOL_SHORT}'s ${EVENT_NAME}. Ask me about the date, timings, participants, theme or the Smart Classroom.`,
      `I'm ${BOT_NAME}, your AI Expo companion. I float, I talk, and I know everything about this event — try me!`
    ]
  },
  bye: {
    keywords: ["bye", "goodbye", "see you", "see ya", "later", "gotta go", "i'm leaving"],
    responses: [
      "See you around! Enjoy the rest of the expo.",
      "Bye for now — come back anytime you have a question.",
      "Take care! Thanks for stopping by."
    ]
  }
};

/* Shown when nothing matched at all */
const fallbackResponses = [
  `I don't have that information yet — ask a teacher-in-charge, or try the Fest Date, Timings, Participants, Theme or Smart Classroom below.`,
  `Hmm, I can't answer that one yet. Try asking about the Date, Timings, Participants, Theme or Smart Classroom.`,
  `That detail isn't available right now. You can ask me about the Fest Date, Timings, Participants, Theme or Smart Classroom instead.`
];

/* Welcome message spoken + displayed when the chat interface first opens */
const welcomeMessage = `Hi! I'm ${BOT_NAME}, the official guide for the ${EVENT_NAME} at ${SCHOOL_SHORT} — this is the first AI Expo in ${SCHOOL_SHORT}'s history! Ask me about the Fest Date, Timings, Participants, Theme or Smart Classroom — by typing, speaking, or tapping a card below.`;
