#!/usr/bin/env python3
"""
DRAPH — local server
=====================
Serves the DRAPH frontend AND proxies "Chat Bot" (text) and natural
"Speak" (voice) requests to the Gemini API
(Interactions API — https://ai.google.dev/gemini-api/docs/interactions).

WHY A PROXY AT ALL?
--------------------
DRAPH is a public kiosk app — at the expo, anyone can open the browser's
dev tools, view source, or just watch the Network tab. If the Gemini API
key ever appeared in the HTML/JS that ships to that browser, it would be
trivial to copy out and use elsewhere on the school's/your bill. So the
key lives ONLY here, server-side, read from an environment variable (or
a local .env file you create yourself — never commit it). The browser
talks only to this local server; this server is the only thing that ever
talks to Google.

The Script Bot (the keyword-matched FAQ system) needs none of this and
keeps working with zero setup, zero internet dependency, and zero cost —
it never touches this server's /api routes at all. Chat Bot and natural
Speak are optional upgrades on top.

RUNNING IT
----------
    pip install google-genai
    export GEMINI_API_KEY="your-key-here"      # or put it in a .env file, see .env.example
    python3 server/server.py

Then open:  http://localhost:8080

If GEMINI_API_KEY isn't set, the server still runs and Script Bot works
normally — Chat Bot and Speak just report themselves unavailable instead
of failing confusingly, and the browser's own built-in voice is used
for speech instead.
"""

import base64
import json
import mimetypes
import os
import sys
import threading
import time
import wave
from io import BytesIO
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent.parent  # project root (one level up from /server)
PORT = int(os.environ.get("PORT", "8080"))
MODEL = os.environ.get("DRAPH_MODEL", "gemini-3-flash-preview")
MAX_OUTPUT_TOKENS = int(os.environ.get("DRAPH_MAX_TOKENS", "420"))
MIN_REQUEST_GAP_S = float(os.environ.get("DRAPH_MIN_REQUEST_GAP", "1.5"))
TTS_MODEL = os.environ.get("DRAPH_TTS_MODEL", "gemini-3.1-flash-tts-preview")
TTS_VOICE = os.environ.get("DRAPH_TTS_VOICE", "Sulafat")  # "Warm" per Google's voice list
TTS_MIN_REQUEST_GAP_S = float(os.environ.get("DRAPH_TTS_MIN_REQUEST_GAP", "0.6"))
# Search grounding is OFF by default: it can roughly double or triple reply
# latency (the model may issue several real web searches before answering)
# and, on some API keys/tiers, fails outright — which previously showed up
# as Chat Bot reliably erroring on every message. A short factual kiosk FAQ
# bot rarely needs live web search anyway. Set DRAPH_ENABLE_SEARCH=1 to
# turn it back on if you want it and have confirmed your key supports it.
ENABLE_SEARCH = os.environ.get("DRAPH_ENABLE_SEARCH", "0").strip() == "1"
EVENT_NAME = "AI Expo 2026\u201327"
SCHOOL_NAME = "Sri R.M. Jain Vidhyashram Sr. Sec. School (SRMJV)"
SCHOOL_SHORT = "SRMJV"
BOT_NAME = "DRAPH"
MIN_SDK_VERSION = (2, 3, 0)


# ---------------------------------------------------------------------------
# .env loading (no extra dependency — a tiny KEY=VALUE parser is enough)
# ---------------------------------------------------------------------------
def load_dotenv(path: Path) -> None:
    if not path.exists():
        return
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


load_dotenv(ROOT / ".env")

# Built-in default so DRAPH works the instant you run this file — no setup
# step required. An environment variable or a local .env file (see
# .env.example) still overrides this if you ever swap in a different key,
# e.g. before rotating credentials or sharing/publishing this project
# somewhere a stranger could read server-side source (this file never
# ships to a visitor's browser either way — see the module docstring).
_BUILT_IN_DEFAULT_KEY = ""  # never commit a real key here — use GEMINI_API_KEY env var / .env
API_KEY = os.environ.get("GEMINI_API_KEY", "").strip() or _BUILT_IN_DEFAULT_KEY


# ---------------------------------------------------------------------------
# DRAPH's Chat Bot persona. The known event facts are kept in ONE place
# (data.js) for the Script Bot; we mirror the short version here so both
# systems agree on the same facts instead of drifting apart. Edit data.js
# for real event details and this stays in sync automatically at runtime
# via read_event_facts_from_data_js().
# ---------------------------------------------------------------------------
SYSTEM_INSTRUCTION_TEMPLATE = """You are DRAPH, a friendly holographic AI guide floating at \
the {event} — the first AI Expo ever held at {school}. You're speaking with real visitors \
at a live school event: students, teachers, and families. Keep every answer warm, clear,
encouraging, and appropriate for a school audience of all ages.

Keep answers SHORT: 2 to 4 sentences unless the visitor clearly asks for more detail. This is \
a spoken, face-to-face kiosk conversation, not a written essay — no long lists or headers.

Known event facts — share these plainly if asked, and say the detail isn't finalised yet \
instead of guessing if it's marked "coming soon":
{event_facts}

Beyond those facts, you're happy to talk about anything the visitor is curious about — how AI \
works, science-fair-style questions, or just friendly conversation."""

_EVENT_FACTS_CACHE = {"text": None, "mtime": None}


def read_event_facts_from_data_js() -> str:
    """Pulls the human-readable 'content' strings out of js/data.js so the
    Chat Bot's facts stay in sync with the Script Bot's, without needing a
    second place to edit them. Falls back to a short static summary if
    data.js can't be parsed for any reason — never crashes the server."""
    data_js_path = ROOT / "js" / "data.js"
    try:
        mtime = data_js_path.stat().st_mtime
        if _EVENT_FACTS_CACHE["text"] is not None and _EVENT_FACTS_CACHE["mtime"] == mtime:
            return _EVENT_FACTS_CACHE["text"]
        raw = data_js_path.read_text(encoding="utf-8")
        import re
        labels = re.findall(r'label:\s*"([^"]+)"', raw)
        contents = re.findall(r'content:\s*`([^`]*)`', raw)
        # data.js interpolates these as JS template-literal ${...} placeholders,
        # which only resolve in the browser — mirror that substitution here so
        # the facts we hand to Gemini read naturally instead of showing raw
        # "${EVENT_NAME}"-style placeholders.
        substitutions = {
            "${EVENT_NAME}": EVENT_NAME, "${SCHOOL_NAME}": SCHOOL_NAME,
            "${SCHOOL_SHORT}": SCHOOL_SHORT, "${BOT_NAME}": BOT_NAME,
        }
        lines = []
        for label, content in zip(labels, contents):
            for placeholder, value in substitutions.items():
                content = content.replace(placeholder, value)
            clean = re.sub(r"<[^>]+>", " ", content)
            clean = re.sub(r"\s+", " ", clean).strip()
            lines.append(f"- {label}: {clean}")
        text = "\n".join(lines) if lines else "- (no event facts configured yet in js/data.js)"
        _EVENT_FACTS_CACHE.update(text=text, mtime=mtime)
        return text
    except Exception:
        return "- (event facts unavailable — see js/data.js)"


# ---------------------------------------------------------------------------
# Gemini call
# ---------------------------------------------------------------------------
_rate_lock = threading.Lock()
_last_request_by_client = {}  # client id (IP) -> monotonic time of last chat request


class RateLimited(Exception):
    pass


class ChatBotError(Exception):
    """A friendly, already-safe-to-show-the-visitor error message."""
    pass


def _load_genai_client():
    """Single place that imports the SDK, checks it's new enough for the
    Interactions API, and builds a client — so every caller gets the same
    specific, actionable error instead of a bare traceback. A version too
    old to have client.interactions is a CONSISTENT failure on every
    single request, which is exactly what an unversioned `pip install`
    can produce if some other tool already installed an older google-genai
    first — this check turns that into a clear message instead of a
    confusing generic one."""
    try:
        from google import genai
    except ImportError:
        raise ChatBotError(
            "This server is missing the google-genai package. Run: python3 install.py "
            "(or: pip install -r requirements.txt)"
        )

    installed = getattr(genai, "__version__", None)
    if installed:
        try:
            parts = tuple(int(p) for p in installed.split(".")[:3])
            if parts < MIN_SDK_VERSION:
                raise ChatBotError(
                    f"google-genai {installed} is installed, but the Interactions API needs "
                    f"{'.'.join(map(str, MIN_SDK_VERSION))} or newer. Run: "
                    f"pip install --upgrade google-genai"
                )
        except ValueError:
            pass  # non-numeric version string — skip the check rather than false-alarm

    client = genai.Client(api_key=API_KEY)
    if not hasattr(client, "interactions"):
        raise ChatBotError(
            "This google-genai install doesn't have the Interactions API "
            "(client.interactions). Run: pip install --upgrade google-genai"
        )
    return client


def _classify_gemini_exception(exc: Exception, model_name: str = None) -> str:
    """Maps a raw exception to a short, safe-to-show-the-visitor reason,
    while the full detail always still goes to the server console (see
    callers) for whoever's actually debugging it."""
    if isinstance(exc, ChatBotError):
        raise exc  # already a good, specific message (e.g. from _load_genai_client) — don't degrade it
    msg = str(exc)
    model_name = model_name or MODEL
    if "API key not valid" in msg or "API_KEY_INVALID" in msg or "401" in msg or "PERMISSION_DENIED" in msg:
        return "The Gemini API key on this server looks invalid or lacks access to this model."
    if "429" in msg or "RESOURCE_EXHAUSTED" in msg or "quota" in msg.lower():
        return "DRAPH is getting a lot of questions right now — please try again in a moment."
    if "404" in msg or "NOT_FOUND" in msg or "not found" in msg.lower():
        return f"The model \u201c{model_name}\u201d isn't available for this key/project."
    if isinstance(exc, TypeError):
        return f"Request setup error ({msg[:120]})."
    # Generic fallback still includes a short, safe slice of the real error —
    # enough to actually diagnose from the chat bubble, not just "try again."
    short = msg.strip().splitlines()[0][:160] if msg.strip() else exc.__class__.__name__
    return f"Couldn't reach Gemini just now ({short})."


def call_gemini(user_text: str, previous_interaction_id, client_id: str = "local"):

    if not API_KEY:
        raise ChatBotError(
            "Chat Bot isn't set up yet — this server doesn't have a GEMINI_API_KEY. "
            "Script Bot still works great in the meantime!"
        )

    with _rate_lock:
        now = time.monotonic()
        if now - _last_request_by_client.get(client_id, 0.0) < MIN_REQUEST_GAP_S:
            raise RateLimited()
        _last_request_by_client[client_id] = now
        if len(_last_request_by_client) > 5000:  # keep memory bounded
            for k in [k for k, t in _last_request_by_client.items() if now - t > 60]:
                _last_request_by_client.pop(k, None)

    system_instruction = SYSTEM_INSTRUCTION_TEMPLATE.format(
        event=EVENT_NAME, school=SCHOOL_NAME, event_facts=read_event_facts_from_data_js()
    )

    try:
        client = _load_genai_client()
        kwargs = dict(
            model=MODEL,
            input=user_text,
            system_instruction=system_instruction,
            generation_config={
                "temperature": 0.9,
                "max_output_tokens": MAX_OUTPUT_TOKENS,
                "top_p": 0.95,
                "thinking_level": "low",
            },
        )
        if ENABLE_SEARCH:
            kwargs["tools"] = [{"type": "google_search"}]
        if previous_interaction_id:
            kwargs["previous_interaction_id"] = previous_interaction_id
        interaction = client.interactions.create(**kwargs)
        text = (getattr(interaction, "output_text", "") or "").strip()
        if not text:
            text = "I'm not sure how to answer that one — could you try asking a different way?"
        return text, getattr(interaction, "id", None)
    except Exception as exc:  # noqa: BLE001 — deliberately broad: this must never crash the server
        print(f"[gemini chat error] {exc.__class__.__name__}: {exc}", file=sys.stderr)
        raise ChatBotError(_classify_gemini_exception(exc))


# ---------------------------------------------------------------------------
# Speech pronunciation fixes — shared logic notes: the client (audio.js)
# applies the equivalent of this before falling back to the browser's own
# voice, so both paths read things the same way regardless of which one
# ends up speaking.
# ---------------------------------------------------------------------------
def fix_pronunciation(text: str) -> str:
    import re
    text = re.sub(r"\bSr\.\s*Sec\.", "Senior Secondary", text, flags=re.IGNORECASE)
    text = re.sub(r"\bSRMJV\b", "S R M J V", text)
    # "2026-27"-style abbreviated year ranges get read digit-by-digit by a
    # lot of TTS engines (the dash + 2-digit tail isn't a pattern their
    # number normalizer recognizes) — spell the second year out in full
    # first ("2026 to 2027") so it's read as two ordinary years instead.
    text = re.sub(
        r"(\d{4})\s*[\u2013\u2014-]\s*(\d{2})\b",
        lambda m: f"{m.group(1)} to {m.group(1)[:2]}{m.group(2)}",
        text,
    )
    return text


# ---------------------------------------------------------------------------
# Text-to-speech (natural voice) — Gemini TTS, see
# https://ai.google.dev/gemini-api/docs/speech-generation
# ---------------------------------------------------------------------------
_tts_rate_lock = threading.Lock()
_last_tts_by_client = {}

# A short "director's note" preamble, per Google's own prompting guidance:
# vague TTS prompts can occasionally get rejected by the model's content
# classifier, and a clear "synthesize speech" instruction plus an explicit
# transcript marker avoids that — it also just gives a warmer performance
# than raw unstyled text would.
TTS_DIRECTOR_PREAMBLE = (
    "Say the following in a warm, friendly, natural, clearly-articulated voice — "
    "like a helpful guide speaking to a visitor in person, with relaxed pacing "
    "and light warmth, not flat or robotic. Speak only the transcript below, "
    "nothing else:\n\n"
)


def pcm_to_wav_bytes(pcm_data: bytes, sample_rate=24000, channels=1, sample_width=2) -> bytes:
    buf = BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(channels)
        wf.setsampwidth(sample_width)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm_data)
    return buf.getvalue()


def call_gemini_tts(text: str, client_id: str = "local") -> bytes:

    if not API_KEY:
        raise ChatBotError("Natural voice isn't set up — this server doesn't have a GEMINI_API_KEY.")

    with _tts_rate_lock:
        now = time.monotonic()
        if now - _last_tts_by_client.get(client_id, 0.0) < TTS_MIN_REQUEST_GAP_S:
            raise RateLimited()
        _last_tts_by_client[client_id] = now
        if len(_last_tts_by_client) > 5000:
            for k in [k for k, t in _last_tts_by_client.items() if now - t > 60]:
                _last_tts_by_client.pop(k, None)

    client = _load_genai_client()  # raises ChatBotError immediately (no point retrying a bad SDK/key)

    spoken_text = fix_pronunciation(text)
    prompt = TTS_DIRECTOR_PREAMBLE + spoken_text

    last_error = None
    # Google's own docs note the TTS model occasionally returns text tokens
    # instead of audio and fails on a small fraction of requests, and
    # recommends retrying — but only the actual generation call, once, with
    # a short backoff. Retrying the whole thing 3x (as this used to) is
    # exactly the kind of thing that turns "a bit slow" into "lagging for
    # minutes" when each attempt is itself a multi-second network call.
    for attempt in range(2):
        try:
            interaction = client.interactions.create(
                model=TTS_MODEL,
                input=prompt,
                response_format={"type": "audio"},
                generation_config={"speech_config": [{"voice": TTS_VOICE}]},
            )
            audio_b64 = getattr(getattr(interaction, "output_audio", None), "data", None)
            if not audio_b64:
                raise RuntimeError("Model returned no audio for this text.")
            pcm_bytes = base64.b64decode(audio_b64)
            return pcm_to_wav_bytes(pcm_bytes)
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            print(f"[gemini tts error] attempt {attempt + 1}: {exc.__class__.__name__}: {exc}", file=sys.stderr)
            if attempt == 0:
                time.sleep(0.4)
            continue

    raise ChatBotError(_classify_gemini_exception(last_error, model_name=TTS_MODEL))


# ---------------------------------------------------------------------------
# HTTP server
# ---------------------------------------------------------------------------
STATIC_EXTENSIONS = {
    ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8", ".json": "application/json",
    ".wav": "audio/wav", ".mp3": "audio/mpeg", ".svg": "image/svg+xml",
    ".png": "image/png", ".jpg": "image/jpeg", ".ico": "image/x-icon",
}


PUBLIC_DIRS = {"css", "js", "assets"}  # plus index.html


class Handler(BaseHTTPRequestHandler):
    server_version = "DRAPH/1.0"

    def log_message(self, fmt, *args):  # quieter, friendlier console output
        sys.stderr.write("  " + (fmt % args) + "\n")

    def _client_id(self) -> str:
        fwd = self.headers.get("X-Forwarded-For", "")
        return (fwd.split(",")[0].strip() if fwd else self.client_address[0]) or "unknown"

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/health":
            self._send_json(200, {
                "ok": True,
                "chatBotConfigured": bool(API_KEY),
                "ttsConfigured": bool(API_KEY),
                "model": MODEL,
                "ttsModel": TTS_MODEL,
            })
            return
        self._serve_static(path)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/api/chat":
            self._handle_chat()
            return
        if path == "/api/speak":
            self._handle_speak()
            return
        self._send_json(404, {"error": "not found"})

    def _handle_chat(self):
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
            raw = self.rfile.read(length) if length else b"{}"
            data = json.loads(raw.decode("utf-8") or "{}")
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, {"error": "Bad request body."})
            return

        message = (data.get("message") or "").strip()
        previous_id = data.get("previous_interaction_id") or None
        if not message:
            self._send_json(400, {"error": "Empty message."})
            return
        if len(message) > 2000:
            self._send_json(400, {"error": "That message is a bit long for DRAPH — try something shorter."})
            return

        try:
            text, interaction_id = call_gemini(message, previous_id, self._client_id())
            self._send_json(200, {"text": text, "interaction_id": interaction_id})
        except RateLimited:
            self._send_json(429, {"error": "One moment — DRAPH is still answering the last question."})
        except ChatBotError as exc:
            self._send_json(503, {"error": str(exc)})
        except Exception as exc:  # noqa: BLE001
            print(f"[unexpected error] {exc}", file=sys.stderr)
            self._send_json(500, {"error": "Something went wrong on DRAPH's end. Please try again."})

    def _handle_speak(self):
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
            raw = self.rfile.read(length) if length else b"{}"
            data = json.loads(raw.decode("utf-8") or "{}")
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, {"error": "Bad request body."})
            return

        text = (data.get("text") or "").strip()
        if not text:
            self._send_json(400, {"error": "Empty text."})
            return
        if len(text) > 3000:
            text = text[:3000]

        try:
            wav_bytes = call_gemini_tts(text, self._client_id())
            self.send_response(200)
            self.send_header("Content-Type", "audio/wav")
            self.send_header("Content-Length", str(len(wav_bytes)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(wav_bytes)
        except RateLimited:
            self._send_json(429, {"error": "voice busy"})
        except ChatBotError as exc:
            self._send_json(503, {"error": str(exc)})
        except Exception as exc:  # noqa: BLE001
            print(f"[unexpected error] {exc}", file=sys.stderr)
            self._send_json(500, {"error": "Something went wrong generating audio."})

    def _serve_static(self, path):
        if path == "/":
            path = "/index.html"
        # prevent path traversal outside the project root
        safe_rel = os.path.normpath(path).lstrip(os.sep).lstrip("/")
        file_path = (ROOT / safe_rel).resolve()
        if ROOT not in file_path.parents and file_path != ROOT:
            self._send_json(403, {"error": "forbidden"})
            return
        # ONLY the public frontend is served. Without this, /server/server.py,
        # /.env, /requirements.txt etc. would be downloadable by anyone.
        rel_parts = file_path.relative_to(ROOT).parts
        if not rel_parts or rel_parts[0] not in PUBLIC_DIRS and rel_parts != ("index.html",):
            self.send_response(404)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(b"404 Not Found")
            return
        if not file_path.exists() or file_path.is_dir():
            self.send_response(404)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(b"404 Not Found")
            return

        ext = file_path.suffix.lower()
        content_type = STATIC_EXTENSIONS.get(ext) or mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
        body = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(body)


def main():
    if not API_KEY:
        print("=" * 70, file=sys.stderr)
        print(" GEMINI_API_KEY is not set — Chat Bot mode will be unavailable.", file=sys.stderr)
        print(" Script Bot works fine without it. To enable Chat Bot:", file=sys.stderr)
        print('   export GEMINI_API_KEY="your-key-here"     (or add it to a .env file)', file=sys.stderr)
        print("=" * 70, file=sys.stderr)

    httpd = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"DRAPH is running at:  http://localhost:{PORT}")
    print(f"Chat Bot model:       {MODEL}  ({'configured' if API_KEY else 'NOT configured'})")
    print(f"Natural voice model:  {TTS_MODEL}  (voice: {TTS_VOICE})  ({'configured' if API_KEY else 'NOT configured — using browser voice instead'})")
    print("Press Ctrl+C to stop.\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        httpd.shutdown()


if __name__ == "__main__":
    main()