#!/usr/bin/env python3
"""
DRAPH — installer
==================
Installs everything the server needs, into the same Python environment
that will run it (uses sys.executable, so there's no ambiguity if your
machine has more than one "python").

Run it with:
    python3 install.py

Then start DRAPH with:
    python3 server/server.py
"""

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIREMENTS = ROOT / "requirements.txt"


def main():
    print("Installing DRAPH's server dependencies...")
    print(f"  Python:       {sys.executable}")
    print(f"  Requirements: {REQUIREMENTS}\n")

    if not REQUIREMENTS.exists():
        print(f"Couldn't find {REQUIREMENTS} — is install.py still inside the DRAPH folder?")
        sys.exit(1)

    cmd = [sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS)]
    result = subprocess.run(cmd, capture_output=True, text=True)
    print(result.stdout)

    if result.returncode != 0 and "externally-managed-environment" in (result.stderr or ""):
        # Common on modern Debian/Ubuntu and Homebrew Python (PEP 668): the
        # system Python refuses plain pip installs to protect itself. This
        # is the officially-sanctioned override for "yes, I know, install
        # anyway" — the simplest fix for a one-machine demo/kiosk setup
        # where a virtual environment would just be one more step to
        # remember at the actual expo.
        print("This system protects its global Python environment (PEP 668).")
        print("Retrying with --break-system-packages...\n")
        cmd.append("--break-system-packages")
        result = subprocess.run(cmd, capture_output=True, text=True)
        print(result.stdout)

    if result.returncode != 0:
        print(result.stderr)
        print("\nSomething went wrong during install. A couple of things to try:")
        print("  - Make sure pip is available:  python3 -m ensurepip --upgrade")
        print("  - Or install directly:          pip install google-genai --break-system-packages")
        sys.exit(result.returncode)

    print("\nAll set! Next steps:")
    print("  1. (optional) Set your own Gemini key — see .env.example")
    print("  2. Run:  python3 server/server.py")
    print("  3. Open: http://localhost:8080")


if __name__ == "__main__":
    main()
